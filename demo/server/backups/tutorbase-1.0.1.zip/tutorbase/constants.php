<?php
/**
 * Constant variables.
 *
 * @package tutorbase
 */

define( 'TUTORBASE_PATH', __DIR__ );
define( 'TUTORBASE_ASSETS_PATH', __DIR__ . '/assets' );
define( 'TUTORBASE_VERSION', '1.0.0' );
