<?php
/**
 * The main template file
 *
 * @package tutorbase
 */

wp_footer();

?>

</body>

</html>