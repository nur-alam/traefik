<script>
	location.href = 'https://droip.com/pricing/?utm_source=droip_dashboard&utm_medium=wp_dashboard&utm_campaign=upgrade_pro&referrer=wordpress_dashboard';
</script>
