(()=>{var r={};/************************************************************************/// The module cache
var e={};// The require function
function n(t){// Check if module is in cache
var u=e[t];if(u!==undefined){return u.exports}// Create a new module (and put it into the cache)
var a=e[t]={exports:{}};// Execute the module function
r[t](a,a.exports,n);// Return the exports of the module
return a.exports}/************************************************************************/// webpack/runtime/rspack_version
(()=>{n.rv=()=>"1.5.7"})();// webpack/runtime/rspack_unique_id
(()=>{n.ruid="bundler=rspack@1.5.7"})();/************************************************************************/})();