(()=>{var t={83650:function(){// this function will load after document content load
window.readyState_complete=t=>{var e=t=>t();document.addEventListener("readystatechange",r=>r.target.readyState==="complete"?typeof t=="function"?setTimeout(()=>e(t)):"":"")};window.addBodyClass=t=>{// History push
var e=new URL(t);var r=e.searchParams.get("tab_page");var o=e.searchParams.get("edit")&&"_edit";document.body.classList.add(r);document.body.classList.add(r+o)};window.selectorById=t=>{return document.getElementById(t)};window.selectorByClass=t=>{return document.getElementsByClassName(t)};/**
 * Function to download json file
 * @param {json} response
 * @param {string} fileName
 */window.json_download=(t,e)=>{var r=new Blob([t],{type:"application/json"});var o=document.createElement("a");o.href=URL.createObjectURL(r);o.download=e;o.click()}},4545:function(){window.selectSearchField=t=>{var e=document.querySelectorAll(t);(()=>{e.forEach(t=>{if(t&&!t.classList.contains("tutor-js-form-select")&&!t.hasAttribute("noDropdown")&&!t.classList.contains("no-tutor-dropdown")){var e=t.hasAttribute("data-searchable");var a=t.options[t.selectedIndex];t.style.display="none";var n,i,s,u,c,l,d,v;t.insertAdjacentHTML("afterend",o(t.options,t.value,e));n=t.nextElementSibling;i=n.querySelector(".tutor-form-select-search");s=i&&i.querySelector("input");v=n.querySelector(".tutor-form-select-dropdown");var f=n.querySelector(".tutor-form-select-label");f.innerText=a&&a.text;n.onclick=t=>{t.stopPropagation();r(document.querySelectorAll(".tutor-js-form-select"),n);n.classList.toggle("is-active");if(s){setTimeout(()=>{s.focus()},100)}v.onclick=t=>{t.stopPropagation()}};r(document.querySelectorAll(".tutor-js-form-select"));c=n.querySelector(".tutor-form-select-options");l=c&&c.querySelectorAll(".tutor-form-select-option");if(l){l.forEach(e=>{e.onclick=r=>{r.stopPropagation();var o=Array.from(t.options);o.forEach((o,a)=>{if(o.value===r.target.dataset.key){var i;(i=c.querySelector(".is-active"))===null||i===void 0?void 0:i.classList.remove("is-active");e.classList.add("is-active");n.classList.remove("is-active");f.innerText=r.target.innerText;f.dataset.value=o.value;t.value=o.value;var s=document.getElementById("save_tutor_option");if(s){s.disabled=false}}});var a=new Event("change",{bubbles:true});t.dispatchEvent(a)}})}var m=t=>{var e=0;t.forEach(t=>{if(t.style.display!=="none"){e+=1}});return e};if(s){s.oninput=t=>{var e,r=false;u=t.target.value.toUpperCase();l.forEach(t=>{d=t.querySelector("[tutor-dropdown-item]");e=d.textContent||d.innerText;if(e.toUpperCase().indexOf(u)>-1){t.style.display="";r="false"}else{r="true";t.style.display="none"}});var o='\n							<div class="tutor-form-select-option noItem tutor-text-center tutor-fs-7">\n								'.concat(window.wp.i18n.__("No item found","tutor"),"\n							</div>\n						");var a=v.querySelector(".tutor-form-select-options");if(0==m(l)){var n=false;a.querySelectorAll(".tutor-form-select-option").forEach(t=>{if(t.classList.contains("noItem")==true){n=true}});if(false==n){a.insertAdjacentHTML("beforeend",o);n=true}}else{if(null!==v.querySelector(".noItem")){v.querySelector(".noItem").remove()}}}}}});var t=document.querySelectorAll(".tutor-js-form-select");t.forEach(t=>{if(t.nextElementSibling){if(t.nextElementSibling.classList.contains("tutor-js-form-select")){t.nextElementSibling.remove()}}});var a=document.querySelectorAll(".tutor-js-form-select");document.onclick=t=>{r(a)}})();function r(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(t){t.forEach(t=>{if(t!==e){t.classList.remove("is-active")}})}}function o(t,e,r){var o="";Array.from(t).forEach(t=>{o+='\n            <div class="tutor-form-select-option '.concat(e===t.value?"is-active":"",'">\n				<span tutor-dropdown-item data-key="').concat(tutor_esc_attr(t.value),'" class="tutor-nowrap-ellipsis" title="').concat(tutor_esc_attr(t.text),'">').concat(tutor_esc_html(t.text),"</span>\n            </div>\n            ")});var a="";if(r){a='\n				<div class="tutor-form-select-search tutor-pt-8 tutor-px-8">\n					<div class="tutor-form-wrap">\n						<span class="tutor-form-icon">\n							<i class="tutor-icon-search" area-hidden="true"></i>\n						</span>\n						<input type="search" class="tutor-form-control" placeholder="'.concat(window.wp.i18n.__("Search ...","tutor"),'" />\n					</div>\n				</div>\n			')}var n='\n			<div class="tutor-form-control tutor-form-select tutor-js-form-select">\n				<span class="tutor-form-select-label" tutor-dropdown-label>'.concat(window.wp.i18n.__("Select","tutor"),'</span>\n				<div class="tutor-form-select-dropdown">\n					').concat(a,'\n					<div class="tutor-form-select-options">\n						').concat(o,"\n					</div>\n				</div>\n			</div>\n        ");return n}};selectSearchField(".tutor-form-select")},80922:function(){window.jQuery(document).ready(t=>{/**
     * data-mce-style attr rename to style
     */t("div.tutor-lesson-wrapper [data-mce-style]").each(function(){t(this).attr("style",t(this).attr("data-mce-style"));t(this).removeAttr("data-mce-style")});t(document).on("click",'.tutor-single-course-lesson-comments button[type="submit"]',function(e){e.preventDefault();var{__}=wp.i18n;var r=t(this);var o=r.closest("form");var a=o.serialize();var n=o.find('textarea[name="comment"]').val();if(n.trim().length===0){tutor_toast(__("Warning","tutor"),__("Blank comment is not allowed.","tutor"),"error");return}t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:a,beforeSend:function t(){r.addClass("is-loading").prop("disabled",true)},complete:function t(){r.removeClass("is-loading");r.removeAttr("disabled")},success:function e(e){var r=o.attr("tutor-comment-reply");// If it's reply then just prepend element.
if(typeof r!=="undefined"&&r!==false){o.before(e.data.html)}else{// Render comments section for new comment.
var a=document.querySelector(".tutor-course-spotlight-comments");a.innerHTML=e.data.html}t(".tutor-comment-line").css("height","calc(100% - 308px)");// Clear text area.
t("textarea").val("")},error:function t(t){r.removeClass("is-loading").prop("disabled",false)}})})})},23825:function(){window.jQuery(document).ready(t=>{/**
     * Share Link enable
     *
     * @since v.1.0.4
     */if(t.fn.ShareLink){var e=t(".tutor-social-share-wrap");if(e.length){var r=JSON.parse(e.attr("data-social-share-config"));e.find(".tutor_share").ShareLink({title:r.title,text:r.text,image:r.image,class_prefix:"s_",width:640,height:480})}}})},63023:function(){window.jQuery(document).ready(t=>{var{__}=window.wp.i18n;/**
	 * Remove course-topic footer from quiz pages
	 */if(t(".tutor-quiz-wrap").length){if(!t(".tutor-table-quiz-attempts").length&&!t(".tutor-quiz-attempt-details").length){t(".tutor-course-topic-single-footer").remove()}}/**
	 * Quiz attempt
	 */var e=t("#tutor-quiz-time-update");// Assign countdown if quiz time element available
if(e.length){// Get timing info from data
var r=JSON.parse(e.attr("data-attempt-settings"));var o=JSON.parse(e.attr("data-attempt-meta"));// Restrict quiz timing if time limit is set
if(o.time_limit.time_limit_seconds>0){var a,n;// Get the timeout timestamp
var i=new Date((a=r.attempt_started_at)===null||a===void 0?void 0:a.replaceAll("-","/")).getTime()+o.time_limit.time_limit_seconds*1e3;var s=new Date((n=o.date_time_now)===null||n===void 0?void 0:n.replaceAll("-","/")).getTime();var u=Date.now()-s;// Set the time interval to show countdown
var c=setInterval(function(){// Distance between current time and the quiz timeout timestamp
var r=Date.now()-u;var a=i-r;// Distance in human readable fragments
var n=Math.floor(a/(1e3*60*60*24));var s=Math.floor(a%(1e3*60*60*24)/(1e3*60*60));var l=Math.floor(a%(1e3*60*60)/(1e3*60));var d=Math.floor(a%(1e3*60)/1e3);// Concat fragments to human redable time
var v="";n?v+=n+"d ":0;v+=(s||0)+"h ";v+=(l||0)+"m ";v+=(d||0)+"s ";// If distance is smaller than 0, then clear the interval and show reattempt alert box
if(a<0){clearInterval(c);e.toggleClass("tutor-quiz-time-expired");// Replace the time with expired text
v="EXPIRED";if(_tutorobject.quiz_options.quiz_when_time_expires==="auto_submit"){// Automatically submit the quiz with the progress so far
t("form#tutor-answering-quiz").submit()}else{// Else if 'auto_abandon' or anything else for now
// Add Disable state button class and disable then
t(".tutor-quiz-answer-next-btn, .tutor-quiz-submit-btn, .tutor-quiz-answer-previous-btn").prop("disabled",true);t("button[name='quiz_answer_submit_btn']").prop("disabled",true);// add alert text
t(".time-remaining span").css("color","#F44337");// Abandon the quiz. The attempt status in the database will be 'attempt_timeout'
t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:{quiz_id:t("#tutor_quiz_id").val(),action:"tutor_quiz_timeout"},success:function r(r){var o=t("#tutor-quiz-time-expire-wrapper").data("attempt-allowed");var a=t("#tutor-quiz-time-expire-wrapper").data("attempt-remaining");var n="#tutor-quiz-time-expire-wrapper";t(n).addClass("tutor-alert-show");// if attempt remaining
if(a>0){t("".concat(n," .tutor-quiz-alert-text")).html(__("Your time limit for this quiz has expired, please reattempt the quiz. Attempts remaining:","tutor")+" "+a+"/"+o// Don't break line
)}else{// if attempt not remaining
if(t(n).hasClass("time-remaining-warning")){t(n).removeClass("time-remaining-warning");t(n).addClass("time-over")}if(t("".concat(n," .flash-info span:first-child")).hasClass("tutor-icon-circle-info")){t("".concat(n," .flash-info span:first-child")).removeClass("tutor-icon-circle-info");t("".concat(n," .flash-info span:first-child")).addClass("tutor-icon-circle-times-line")}e.toggleClass("tutor-quiz-time-expired");t("#tutor-start-quiz").hide();t("".concat(n," .tutor-quiz-alert-text")).html("".concat(__("Unfortunately, you are out of time and quiz attempts. ","tutor")));// No attempt is remaining, so reload the page.
window.location.reload(true)}},complete:function t(){}})}}// Update the alert content based on timing
e.html(v);// clearTimeout(tutor_quiz_interval);
// return;
if(v=="EXPIRED"){e.addClass("color-text-error")}/**
				 * dynamically update progress indicator
				 *
				 * @since v2.0.0
				 */if(a){// convert distance in sec
var f=a/1e3;// get total time duration in sec
var m=o.time_limit.time_limit_seconds;//calculate progress
var p=Math.ceil(f*100/m);var _=document.querySelector(".quiz-time-remaining-progress-circle");var h=document.querySelector(".quiz-time-remaining-progress-circle svg");if(h&&_){var g=44-44*(p/100);if(p<=0){p=0;// if time out red the progress circle
_.innerHTML='<svg viewBox="0 0 50 50" width="50" height="50">\n														<circle cx="0" cy="0" r="11"></circle>\n													</svg>';_.setAttribute("class","quiz-time-remaining-expired-circle")}h.setAttribute("style","stroke-dashoffset: ".concat(g,";"))}}},1e3)}else{// If no time limit is set, show 'No Limit' message
e.html(__("No Limit","tutor"))}}var l=t("form#tutor-start-quiz");if(l.length){if(_tutorobject.quiz_options.quiz_auto_start==1){l.submit()}}})},90521:function(){window.jQuery(document).ready(t=>{var{__}=window.wp.i18n;// Currently only these types of question supports answer reveal mode.
var e=["true_false","single_choice","multiple_choice"];var r=_tutorobject.quiz_options;var o=new Map;t(".tutor-sortable-list").on("sortchange",a);function a(e,r){var a=parseInt(t(this).closest(".quiz-attempt-single-question").attr("id").match(/\d+/)[0],10);if(!o.get(a)){o.set(a,true)}}function n(){return Number(_tutorobject.quiz_answer_display_time)||2e3}function i(){return"reveal"===r.feedback_mode}function s(){return _tutorobject.quiz_options.question_layout_view}function u(t){return'<span class="tutor-quiz-answer-single-info tutor-color-success tutor-mt-8">\n            <i class="tutor-icon-mark tutor-color-success" area-hidden="true"></i>\n            '.concat(t,"\n        </span>")}function c(e){var r=false;// Prepare answer array
var o=JSON.parse(window.tutor_quiz_context.split("").reverse().join(""));!Array.isArray(o)?o=[]:0;if(s()!=="question_below_each_other"){t(".tutor-quiz-answer-single-info").remove()}t(".tutor-quiz-answer-single").removeClass("tutor-quiz-answer-single-correct tutor-quiz-answer-single-incorrect");var a=true;var n=e.find("input");var c=e.find('input[type="radio"]:checked, input[type="checkbox"]:checked');if(i()){// Loop through every single checked radio/checkbox input field
c.each(function(){var e=t(this);var r=o.indexOf(e.val())>-1;// $input.attr('data-is-correct') == '1';
// And check if the answer is correct
if(!r){a=false}});// Loop through all the inputs regardless of correct/incorrect
n.each(function(){var n=t(this);var i=n.attr("type");// Reveal mode feature is currently available for only radio and checkbox type answers
if(i==="radio"||i==="checkbox"){var s=o.indexOf(n.val())>-1;// $input.attr('data-is-correct') == '1';
var c=n.is(":checked");if(s){n.closest(".tutor-quiz-answer-single").addClass("tutor-quiz-answer-single-correct").append(u(__("Correct Answer","tutor"))).find(".tutor-quiz-answer-single-info:eq(1)").remove()}else{if(n.prop("checked")){n.closest(".tutor-quiz-answer-single").addClass("tutor-quiz-answer-single-incorrect")}}if(s&&!c){n.attr("disabled","disabled");a=false;r=true}// Display answer explanation if available
e.find(".tutor-quiz-explanation-wrapper").removeClass("tutor-d-none")}})}if(a){r=true}return r}/**
     *
     * Validate whether draggable required question has all answers
     * 
     * @since 2.7.2
     * @param {Object} required_answer_wrap 
     * @returns {boolean}
     */function l(e){var r=true;var o=e[0];var a=t(o).find(".tutor-dropzone");if(a.length>0){Object.values(a).forEach(e=>{if(e instanceof Element&&e.classList.contains("tutor-dropzone")){if(t(e).has("input").length===0){r=false}}})}return r}/**
     * Quiz Validation Helper
     *
     * @since v.1.6.1
     */function d(e,r){var a=e.find(".quiz-answer-required");if(a.length){var n=parseInt(e.attr("id").match(/\d+/)[0],10);var i=o.get(n);var s=e.find(".tutor-draggable");var u=e.find(".ui-sortable");/**
             * Radio field validation
             *
             * @type {jQuery}
             *
             * @since v.1.6.1
             */var c=a.find("input");if(c.length){var d=c.attr("type");if(d==="radio"){if(a.find('input[type="radio"]:checked').length==0){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("Please select an option to answer","tutor"),"</p>"));r=false}}else if(d==="checkbox"){if(a.find('input[type="checkbox"]:checked').length==0){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("Please select at least one option to answer.","tutor"),"</p>"));r=false}}else if(d==="text"){//Fill in the gaps if many, validation all
c.each(function(o,a){if(!t(a).val().trim().length){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("The answer for this question is required","tutor"),"</p>"));r=false}})}}if(a.find("textarea").length){if(a.find("textarea").val().trim().length<1){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("The answer for this question is required","tutor"),"</p>"));r=false}}//Validate draggable quiz questions
if(s.length){var v=l(a);if(!v){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("The answer for this question is required","tutor"),"</p>"));r=false}}//Validate sortable quiz questions
if(i===undefined&&u.length){e.find(".answer-help-block").html('<p style="color: #dc3545">'.concat(__("The answer for this question is required","tutor"),"</p>"));r=false}}return r}/**
     * Quiz view
     * @date 22 Feb, 2019
     * @since v.1.0.0
     */t(".tutor-quiz-next-btn-all").prop("disabled",false);t(".quiz-attempt-single-question input").filter('[type="radio"], [type="checkbox"]').change(function(){if(t(".tutor-quiz-time-expired").length===0){t(".tutor-quiz-next-btn-all").prop("disabled",false)}});t(document).on("click",".tutor-quiz-answer-next-btn, .tutor-quiz-answer-previous-btn",function(r){r.preventDefault();var o=t(".tutor-quiz-question-counter>span:first-child");var a=parseInt(t(this).closest("[data-question_index]").data("question_index"));// Show previous quiz if press previous button
if(t(this).hasClass("tutor-quiz-answer-previous-btn")){t(this).closest(".quiz-attempt-single-question").hide().prev().show();o.text(a-1);return}var s=t(this);var u=s.closest(".quiz-attempt-single-question");var l=parseInt(s.closest(".quiz-attempt-single-question").attr("id").match(/\d+/)[0],10);var v=s.closest(".quiz-attempt-single-question").attr("data-next-question-id");/**
         * Validating required answer
         * @type {jQuery}
         *
         * @since v.1.6.1
         */var f=true;f=d(u,f);if(!f){return}var m=c(u);/**
         * If not reveal mode then check feedback response
         * 
         * Since validation already checked above, now user's ans is correct 
         * or not they should move forward. In reveal mode if feedback response is false
         * then it was freezing the process.
         * 
         * @since v2.0.9
         */if(!i()){if(!m){return}}if(v){var p=t(v);if(p&&p.length){/**
                 * check if reveal mode wait for 500ms then
                 * hide question so that correct answer reveal
                 * @since 1.8.10
                 */if(i()&&e.includes(u.data("question-type"))){setTimeout(()=>{t(".quiz-attempt-single-question").hide();p.show()},n())}else{t(".quiz-attempt-single-question").hide();p.show()}/**
                 * If pagination exists, set active class
                 */if(t(".tutor-quiz-questions-pagination").length){t(".tutor-quiz-question-paginate-item").removeClass("active");t('.tutor-quiz-questions-pagination a[href="'+v+'"]').addClass("active")}// Increase counter
o.text(a+1)}}});t(document).on("click",".tutor-quiz-question-paginate-item",function(e){e.preventDefault();var r=t(this);var o=t(r.attr("href"));t(".quiz-attempt-single-question").hide();o.show();//Active Class
t(".tutor-quiz-question-paginate-item").removeClass("active");r.addClass("active")});/**
     * Limit Short Answer Question Type
     */t(document).on("keyup","textarea.question_type_short_answer, textarea.question_type_open_ended",function(e){var r=t(this);var o=r.val();var a=r.hasClass("question_type_short_answer")?_tutorobject.quiz_options.short_answer_characters_limit:_tutorobject.quiz_options.open_ended_answer_characters_limit;if(!a){return}var n=a-o.length;if(n<1){r.val(o.substr(0,a));n=0}r.closest(".quiz-attempt-single-question").find(".characters_remaining").html(n)});t(document).on("submit","#tutor-answering-quiz",function(r){r.preventDefault();var o=t(".quiz-attempt-single-question");var a=document.querySelector(".tutor-quiz-submit-btn");var u=t(r.target);var l=true;var v=true;var f=false;if(o.length){o.each(function(r,o){l=d(t(o),l);v=c(t(o));if(e.includes(t(o).data("question-type"))){f=true}})}//If auto submit option is enabled after time expire submit current progress
if(_tutorobject.quiz_options.quiz_when_time_expires==="auto_submit"&&t("#tutor-quiz-time-update").hasClass("tutor-quiz-time-expired")){l=true;v=true}if(l&&v){var m=500;if(i()&&s()==="question_below_each_other"&&f){m=n();u.find(":submit").addClass("is-loading").attr("disabled","disabled")}setTimeout(()=>{r.target.submit()},m)}else{if(a){a.classList.remove("is-loading");a.disabled=false}}});t(".tutor-quiz-submit-btn").click(function(r){r.preventDefault();var o=t(".quiz-attempt-single-question");var a=o[o.length-1];var s=t(a).data("question-type");if(i()&&e.includes(s)){var u=true;if(o.length){o.each(function(e,r){u=d(t(r));u=c(t(r))})}t(this).attr("disabled","disabled");setTimeout(()=>{t(this).addClass("is-loading");t("#tutor-answering-quiz").submit()},n())}else{t(this).attr("disabled","disabled").addClass("is-loading");t("#tutor-answering-quiz").submit()}});//warn user before leave page if quiz is running
var v=t("#tutor-quiz-time-update");// @todo: check the button class functionality
t(document).on("click","a",function(e){// if user click on ask question then return, no warning.
if(e.target.classList.contains("sidebar-ask-new-qna-btn")||e.target.classList.contains("tutor-quiz-question-paginate-item")){return}if(v.length>0&&v.text()!="EXPIRED"){e.preventDefault();e.stopImmediatePropagation();var r;var o={title:__("Abandon Quiz?","tutor"),description:__("Do you want to abandon this quiz? The quiz will be submitted partially up to this question if you leave this page.","tutor"),buttons:{keep:{title:__("Yes, leave quiz","tutor"),id:"leave",class:"tutor-btn tutor-btn-outline-primary",callback:function e(){var e=t("form#tutor-answering-quiz").serialize()+"&action="+"tutor_quiz_abandon";t.ajax({url:window._tutorobject.ajaxurl,type:"POST",data:e,beforeSend:function t(){document.querySelector("#tutor-popup-leave").innerHTML=__("Leaving...","tutor")},success:function t(t){if(t.success){location.reload(true)}else{alert(__("Something went wrong","tutor"))}},error:function t(){alert(__("Something went wrong","tutor"));r.find("[data-tutor-modal-close]").click()}})}},reset:{title:__("Stay here","tutor"),id:"reset",class:"tutor-btn tutor-btn-primary tutor-ml-20",callback:function t(){r.find("[data-tutor-modal-close]").click()}}}};r=new window.tutor_popup(t,"").popup(o)}});/* Disable start quiz button  */t("body").on("submit","form#tutor-start-quiz",function(){t(this).find("button").prop("disabled",true)})})},12155:function(){window.jQuery(document).ready(t=>{var{__}=wp.i18n;t(document).on("click",".tutor-course-wishlist-btn",function(e){e.preventDefault();var r=t(this);var o=r.attr("data-course-id");t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:{course_id:o,action:"tutor_course_add_to_wishlist"},beforeSend:function t(){r.attr("disabled","disabled").addClass("is-loading")},success:function e(e){if(e.success){if(e.data.status==="added"){r.find("i").addClass("tutor-icon-bookmark-bold").removeClass("tutor-icon-bookmark-line")}else{r.find("i").addClass("tutor-icon-bookmark-line").removeClass("tutor-icon-bookmark-bold");r.blur()}}else{var o;var a;tutor_toast(__("Error","tutor-pro"),(a=e===null||e===void 0?void 0:(o=e.data)===null||o===void 0?void 0:o.message)!==null&&a!==void 0?a:"Something went wrong!!","error");t(".tutor-login-modal").addClass("tutor-is-active");r.blur()}},error:function t(t,e,o){tutor_toast(__("Error","tutor-pro"),"Something went wrong!!","error");r.blur()},complete:function t(){r.removeAttr("disabled").removeClass("is-loading")}})})})},53579:function(){window.jQuery(document).ready(t=>{// course archive page added_to_cart event change view cart html
t(document).on("added_to_cart",function(t,e,r,o){o.removeClass("is-loading");o.siblings("a.added_to_cart").addClass("tutor-btn tutor-btn-outline-primary tutor-btn-md tutor-btn-block").prepend('<span class="tutor-icon-cart-line tutor-mr-8"></span>')});t(document).on("adding_to_cart",function(t,e){e.addClass("is-loading");setTimeout(()=>{e.removeClass("is-loading")},4e3)})})},6402:function(){document.addEventListener("DOMContentLoaded",function(){var{__:t,_x:e,_n:r,_nx:o}=wp.i18n;/**
   * Export purchase history
   *
   * @since v2.0.0
   */var a=document.querySelectorAll(".tutor-export-purchase-history");for(var n of a){if(n){n.onclick=t=>{var e=t.currentTarget;var r="order-".concat(e.dataset.order,"-purchase-history.csv");var o=[{"Order ID ":e.dataset.order,"Course Name":e.dataset.courseName,Price:e.dataset.price,Date:e.dataset.date,Status:e.dataset.status}];i(o,r)}}}/**
   * Export CSV file
   *
   * @param {*} data | data that will be used for generating CSV file
   * @param {*} filename | filename of CSV file
   * @since v2.0.0
   */function i(t,e){var r=Object.keys(t[0]);var o=[r.join(","),t.map(t=>r.map(e=>t[e]).join(",")).join("\n")].join("\n");//generate csv
var a=new Blob([o],{type:"text/csv;charset=utf-8"});var n=URL.createObjectURL(a);var i=document.createElement("a");i.setAttribute("href",n);i.setAttribute("download",e);i.style.visibility="hidden";document.body.appendChild(i);i.click();document.body.removeChild(i)}})},11602:function(){/**
 * Create new draft course
 *
 * @since v2.0.3
 */document.addEventListener("DOMContentLoaded",function(){// Course save draft
var t=document.getElementById("tutor-course-save-draft");if(t){t.onclick=e=>{e.preventDefault();t.setAttribute("disabled","disabled");t.classList.add("is-loading");document.getElementById("tutor-frontend-course-builder").submit()}}/**
	 * Fix - Table last row context menu hidden for frontend dashboard.
	 *
	 * @since 2.2.4
	 */var e=jQuery(".tutor-table-responsive .tutor-table .tutor-dropdown");if(e.length){var r=jQuery(".tutor-table-responsive .tutor-table").height();jQuery(".tutor-table-responsive").css("min-height",r+110)}})},20193:function(){document.addEventListener("DOMContentLoaded",()=>{// Toggle menu in mobile view
var t=window.jQuery;t(".tutor-dashboard .tutor-dashboard-menu-toggler").click(function(){var e=t(".tutor-dashboard-left-menu");e.closest(".tutor-dashboard").toggleClass("is-sidebar-expanded");if(e.css("display")!=="none"){e.get(0).scrollIntoView({block:"start"})}})})},35852:function(t,e,r){var{get_response_message:o}=r(10836);window.jQuery(document).ready(t=>{var{__}=wp.i18n;t('.tutor-settings-pass-field [name="confirm_new_password"]').on("input",function(){var e=t('[name="new_password"]');var r=(e.val()||"").trim();var o=r&&t(this).val()===r;t(this).parent().find(".tutor-validation-icon")[o?"show":"hide"]()});t(".tutor-profile-password-reset").click(function(e){e.preventDefault();var r=t(this);var a=r.closest("form");var n=a.serializeObject();n.action="tutor_profile_password_reset";t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:n,beforeSend:()=>{r.addClass("is-loading")},success:t=>{var{success:e}=t;if(e){window.tutor_toast(__("Success","tutor"),o(t),"success");window.location.reload()}else{window.tutor_toast(__("Error","tutor"),o(t),"error")}},complete:()=>{r.removeClass("is-loading")}})})})},48621:function(t,e,r){var{get_response_message:o}=r(10836);var a=t=>{var e=new RegExp("^(https?:\\/\\/)?"+// protocol
"((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|"+// domain name
"((\\d{1,3}\\.){3}\\d{1,3}))"+// OR ip (v4) address
"(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*"+// port and path
"(\\?[;&a-z\\d%_.~+=-]*)?"+// query string
"(\\#[-a-z\\d_]*)?$","i");// fragment locator
return!!e.test(t)};var n=(t,e,r)=>{// Read image as data url
var o=new FileReader;o.addEventListener("load",()=>{// Read as image to retrieve dimension
var a=new Image;a.addEventListener("load",()=>{var{width:o,height:n}=a;var i=0;var s=0;var u=o;var c=n;if(e.width==e.height){i=o>n?(o-n)/2:0;s=n>o?(n-o)/2:0;u=o>n?n:o;c=n>o?o:n}e.height=e.height||n/o*e.width;var l=e.width>o?o:e.width;var d=e.width>o?n:e.height;// Create the destination canvas
var v=document.createElement("canvas");v.width=l;v.height=d;var f=v.getContext("2d");f.drawImage(a,i,s,u,c,0,0,v.width,v.height);v.toBlob(e=>{e.name=t.name;e.lastModified=t.lastModified;var o=new FileReader;o.addEventListener("load",()=>{r(e,o.result)});o.readAsDataURL(e)},"image/jpeg")});a.src=o.result});o.readAsDataURL(t)};window.jQuery(document).ready(t=>{var{__}=wp.i18n;/**
	 * Profile Photo and Cover Photo editor
	 *
	 * @since  v.1.7.5
	 */var e=function e(e){this.dialogue_box=e.find("#tutor_photo_dialogue_box");this.open_dialogue_box=function(t){this.dialogue_box.attr("name",t);this.dialogue_box.trigger("click")};this.upload_selected_image=function(e,r){var o=tutor_get_nonce_data(true);var a=this;a.toggle_loader(e,true);// Prepare payload to upload
var n=new FormData;n.append("action","tutor_user_photo_upload");n.append("photo_type",e);n.append("photo_file",r,r.name);n.append(o.key,o.value);// Upload the image to server
var i=this;t.ajax({url:window._tutorobject.ajaxurl,data:n,type:"POST",processData:false,contentType:false,error:a.error_alert,success:function t(){var t=i.title_capitalize(e.replace("_"," "));var r=__("Success","tutor");var o=t+" Changed Successfully!";if("Profile Photo"===t){o=__("Profile Photo Changed Successfully!","tutor")}if("Cover Photo"===t){o=__("Cover Photo Changed Successfully!","tutor")}tutor_toast(r,o,"success")},complete:function t(){a.toggle_loader(e,false)}})};this.title_capitalize=function(t){var e=t.split(" ");for(var r=0;r<e.length;r++){e[r]=e[r].charAt(0).toUpperCase()+e[r].slice(1)}return e.join(" ")};this.accept_upload_image=function(e,r){var o=r.currentTarget.files[0]||null;e.update_preview(r.currentTarget.name,o);// Resize 
n(o,{width:1200},t=>{e.upload_selected_image(r.currentTarget.name,t)});t(r.currentTarget).val("")};this.delete_image=function(e){var r=this;r.toggle_loader(e,true);t.ajax({url:window._tutorobject.ajaxurl,data:{action:"tutor_user_photo_remove",photo_type:e},type:"POST",error:r.error_alert,complete:function t(){r.toggle_loader(e,false)}})};this.update_preview=function(t,r){var o=e.find(t=="cover_photo"?"#tutor_cover_area":"#tutor_profile_area");if(!r){o.css("background-image","url("+o.data("fallback")+")");this.delete_image(t);return}var a=new FileReader;a.onload=function(t){o.css("background-image","url("+t.target.result+")")};a.readAsDataURL(r)};this.toggle_profile_pic_action=function(t){var r=t===undefined?"toggleClass":t?"addClass":"removeClass";e[r]("pop-up-opened")};this.error_alert=function(){tutor_toast(__("Error","tutor"),__("Maximum file size exceeded!","tutor"),"error");// alert('Something Went Wrong.');
};this.toggle_loader=function(t,r){e.find("#tutor_photo_meta_area .loader-area").css("display",r?"block":"none")};this.initialize=function(){var t=this;this.dialogue_box.change(function(e){t.accept_upload_image(t,e)});e.find("#tutor_profile_area .tutor_overlay, #tutor_pp_option>div:last-child").click(function(){t.toggle_profile_pic_action()});// Upload new
e.find(".tutor_cover_uploader").click(function(){t.open_dialogue_box("cover_photo")});e.find(".tutor_pp_uploader").click(function(){t.open_dialogue_box("profile_photo")});// Delete existing
e.find(".tutor_cover_deleter").click(function(){t.update_preview("cover_photo",null)});e.find(".tutor_pp_deleter").click(function(){t.update_preview("profile_photo",null)})}};var r=t("#tutor_profile_cover_photo_editor");r.length>0?new e(r).initialize():0;// Save profile settings with ajax
t(".tutor-profile-settings-save").click(function(e){e.preventDefault();var r=t(this);var a=r.closest("form");var n=a.serializeObject();var i=document.querySelector("[name=phone_number]");/**
		 * Basic markup for profile bio
		 * @since 2.2.4
		 */if(window.tinyMCE!==undefined){var s=tinyMCE.get("tutor_profile_bio");n.tutor_profile_bio=s.getContent({format:"html"})}if(n.phone_number&&!n.phone_number.match(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im)){i.classList.add("invalid");tutor_toast(__("Invalid","tutor"),__("Invalid phone number","tutor"),"error");i.focus();return false}else{i.classList.remove("invalid")}n.action="tutor_update_profile";t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:n,beforeSend:()=>{r.addClass("is-loading")},success:t=>{var{success:e}=t;if(e){window.tutor_toast(__("Success","tutor"),o(t),"success")}else{window.tutor_toast(__("Error","tutor"),o(t),"error")}},complete:()=>{r.removeClass("is-loading")}})});t("#user_social_form").submit(function(e){e.preventDefault();var r=t(this).find("button[type=submit]");var a=_tutorobject.ajaxurl;var n=t(this).serializeObject();t.ajax({url:a,type:"POST",data:n,beforeSend:()=>{r.addClass("is-loading")},success:t=>{var{success:e}=t;var r=o(t);if(e){window.tutor_toast(__("Success","tutor"),r,"success")}else{window.tutor_toast(__("Error","tutor"),r,"error")}},complete:()=>{r.removeClass("is-loading")}})})})},44789:function(){document.addEventListener("DOMContentLoaded",()=>{var t=window.jQuery;/**
     * Withdraw Form Tab/Toggle
     *
     * @since v.1.1.2
     */t('.tutor-dashboard-setting-withdraw input[name="tutor_selected_withdraw_method"]').on("change",function(e){var r=t(this);var o=r.closest("form");o.find(".withdraw-method-form").hide();o.find(".withdraw-method-form").hide().filter('[data-withdraw-form="'+r.val()+'"]').show()})})},1838:function(){window.jQuery(document).ready(t=>{var{__}=window.wp.i18n;/**
     * Retake course
     *
     * @since v1.9.5
     */t(".tutor-course-retake-button").prop("disabled",false).click(function(e){e.preventDefault();var r=t(this).attr("href");var o=t(this).data("course_id");var a={title:__("Override Previous Progress","tutor"),description:__("Before continue, please decide whether to keep progress or reset.","tutor"),buttons:{reset:{title:__("Reset Data","tutor"),class:"tutor-btn tutor-btn-primary",callback:function e(e){t.ajax({url:window._tutorobject.ajaxurl,type:"POST",data:{action:"tutor_reset_course_progress",course_id:o},beforeSend:()=>{e.prop("disabled",true).addClass("is-loading")},success:function t(t){if(t.success){window.location.assign(t.data.redirect_to)}else{alert((t.data||{}).message||__("Something went wrong","tutor"))}},complete:function t(){e.prop("disabled",false).removeClass("is-loading")}})}},keep:{title:__("Keep Data","tutor"),class:"tutor-btn tutor-btn-outline-primary tutor-ml-20",attr:"data-tutor-modal-close",callback:function t(){window.location.assign(r)}}}};new window.tutor_popup(t,"icon-gear").popup(a)})});readyState_complete(()=>{var t=document.querySelector(".tutor-video-player .loading-spinner");if(null!==t){t.remove()}})},39356:function(){jQuery(document).ready(function(t){var{__,_x:e,_n:r,_nx:o}=wp.i18n;/**
	 *
	 * Instructor list filter
	 *
	 * @since  v.1.8.4
	 */// Get values on course category selection
t("[tutor-instructors]").each(function(){var e=t(this);var r={};var o;var a=document.querySelector(".tutor-ratings-stars i.is-active");var i=0;if(a){i=a.dataset.value}function s(o,a,n){// Prepare http payload
var i=e.find("[tutor-instructors-content]");var s=i.html();var u=e.data();u.current_page=n||1;o?r[o]=a:r={};r.attributes=u;r.action="load_filtered_instructor";// Append spinner
i.html('<div class="tutor-spinner-wrap"><span class="tutor-spinner" area-hidden="true"></span></div>');t.ajax({url:window._tutorobject.ajaxurl,data:r,type:"POST",success:function t(t){i.html((t.data||{}).html)},error:function t(){i.html(s);tutor_toast(__("Failed","tutor"),__("Request Error","tutor"),"error")}})}e.on("change",'[tutor-instructors-filter-category] [type="checkbox"]',function(){var e={};t(this).closest("[tutor-instructors-filter-category]").find("input:checked").each(function(){e[t(this).val()]=t(this).parent().text()});var r=Object.keys(e);s(t(this).attr("name"),r)}).on("click","[tutor-instructors-filter-rating]",function(t){var e=t.target.dataset.value;if(e!=i){s("rating_filter",e)}i=e}).on("change","[tutor-instructors-filter-sort]",function(t){var e=t.target.value;s("short_by",e)})// Get values on search keyword change
.on("input","[tutor-instructors-filter-search]",function(){var e=t(this).val();o?window.clearTimeout(o):0;o=window.setTimeout(function(){s("keyword",e);o=null},500)}).on("click","[data-page_number]",function(e){// On pagination click
e.preventDefault();s(null,null,t(this).data("page_number"))})// Clear filter
.on("click","[tutor-instructors-filter-clear]",function(){var e=t(this).closest("[tutor-instructors-filters]");e.find('input[type="checkbox"]').prop("checked",false);e.find("[tutor-instructors-filter-search]").val("");var r=document.querySelectorAll("[tutor-instructors-filter-rating]");//remove star selection
for(var o of r){if(o.classList.contains("active")){o.classList.remove("active")}if(o.classList.contains("tutor-icon-star-bold")){o.classList.remove("tutor-icon-star-bold");o.classList.add("tutor-icon-star-line")}}n.innerHTML="";s()})});/**
	 * Show start active as per click
	 *
	 * @since v2.0.0
	 */var a=document.querySelectorAll("[tutor-instructors-filter-rating]");var n=document.querySelector("[tutor-instructors-filter-rating-count]");for(var i of a){i.onclick=t=>{var e=t.currentTarget;//remove active if has
for(var r of a){if(r.classList.contains("is-active")){r.classList.remove("is-active")}if(r.classList.contains("tutor-icon-star-bold")){r.classList.remove("tutor-icon-star-bold");r.classList.add("tutor-icon-star-line")}}//show stars active as click
var o=Number(t.target.dataset.value);var i=__("star","tutor");if(o>1){i=__("stars","tutor")}if(!e.classList.contains("is-active")){e.classList.add("is-active")}if(!e.classList.contains("tutor-icon-star-bold")){e.classList.remove("tutor-icon-star-line");e.classList.add("tutor-icon-star-bold")}n.innerHTML="".concat(o," ").concat(i)}}})},10836:function(t,e,r){"use strict";r.r(e);r.d(e,{get_response_message:()=>o});var o=(t,e)=>{var{__}=wp.i18n;var{data:r={}}=t||{};var{message:o=e||__("Something Went Wrong!","tutor")}=r;return o}}};/************************************************************************/// The module cache
var e={};// The require function
function r(o){// Check if module is in cache
var a=e[o];if(a!==undefined){return a.exports}// Create a new module (and put it into the cache)
var n=e[o]={exports:{}};// Execute the module function
t[o](n,n.exports,r);// Return the exports of the module
return n.exports}/************************************************************************/// webpack/runtime/define_property_getters
(()=>{r.d=(t,e)=>{for(var o in e){if(r.o(e,o)&&!r.o(t,o)){Object.defineProperty(t,o,{enumerable:true,get:e[o]})}}}})();// webpack/runtime/has_own_property
(()=>{r.o=(t,e)=>Object.prototype.hasOwnProperty.call(t,e)})();// webpack/runtime/make_namespace_object
(()=>{// define __esModule on exports
r.r=t=>{if(typeof Symbol!=="undefined"&&Symbol.toStringTag){Object.defineProperty(t,Symbol.toStringTag,{value:"Module"})}Object.defineProperty(t,"__esModule",{value:true})}})();// webpack/runtime/rspack_version
(()=>{r.rv=()=>"1.4.11"})();// webpack/runtime/rspack_unique_id
(()=>{r.ruid="bundler=rspack@1.4.11"})();/************************************************************************/var o={};// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(()=>{"use strict";// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_define_property.js
function t(t,e,r){if(e in t){Object.defineProperty(t,e,{value:r,enumerable:true,configurable:true,writable:true})}else t[e]=r;return t};// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_object_spread.js
function e(e){for(var r=1;r<arguments.length;r++){var o=arguments[r]!=null?arguments[r]:{};var a=Object.keys(o);if(typeof Object.getOwnPropertySymbols==="function"){a=a.concat(Object.getOwnPropertySymbols(o).filter(function(t){return Object.getOwnPropertyDescriptor(o,t).enumerable}))}a.forEach(function(r){t(e,r,o[r])})}return e};// CONCATENATED MODULE: ./node_modules/@swc/helpers/esm/_async_to_generator.js
function o(t,e,r,o,a,n,i){try{var s=t[n](i);var u=s.value}catch(t){r(t);return}if(s.done)e(u);else Promise.resolve(u).then(o,a)}function a(t){return function(){var e=this,r=arguments;return new Promise(function(a,n){var i=t.apply(e,r);function s(t){o(i,a,n,s,u,"next",t)}function u(t){o(i,a,n,s,u,"throw",t)}s(undefined)})}};// CONCATENATED MODULE: ./assets/react/helper/ajax-handler.js
function n(t){return a(function*(){try{var e=yield fetch(window._tutorobject.ajaxurl,{method:"POST",body:t});return e}catch(t){tutor_toast(__("Operation failed","tutor"),t,"error")}})()};// CONCATENATED MODULE: ./assets/react/admin-dashboard/segments/filter.js
/**
 * On click add filter value on the url
 * and refresh page
 *
 * Handle bulk action
 *
 * @package Filter / sorting
 * @since v2.0.0
 */document.addEventListener("DOMContentLoaded",function(){var{__,_x:t,_n:e,_nx:r}=wp.i18n;var o=document.getElementById("tutor-common-confirmation-modal");var i=document.getElementById("tutor-common-confirmation-form");var s=document.querySelectorAll(".tutor-filter-select");s.forEach(t=>{t.addEventListener("change",t=>{var e=t.target.name;var r=t.target.value;if(r.length){window.location=b(e,r)}else{window.location=y(e)}},{once:true})});var u=document.querySelectorAll(".tutor-admin-dashboard-filter-form");u.forEach(t=>{t.addEventListener("submit",t=>{t.preventDefault();var e=new FormData(t.target);var r=Object.fromEntries(e);var o=new URL(window.location.href);var a=o.searchParams;a.set("paged",1);for(var n in r){var i=r[n];if(i){a.set(n,i)}else{a.delete(n)}}window.location=o})});var c=document.getElementById("tutor-backend-filter-course");if(c){c.addEventListener("change",t=>{window.location=b("course-id",t.target.value)},{once:true})}var l=document.getElementById("tutor-backend-filter-category");if(l){l.addEventListener("change",t=>{window.location=b("category",t.target.value)},{once:true})}var d=document.getElementById("tutor-backend-filter-order");if(d){d.addEventListener("change",t=>{window.location=b("order",t.target.value)},{once:true})}var v=document.getElementById("tutor-backend-filter-payment-status");v===null||v===void 0?void 0:v.addEventListener("change",t=>{window.location=b("payment-status",t.target.value)},{once:true});var f=document.getElementById("tutor-admin-search-filter-form");var m=document.getElementById("tutor-backend-filter-search");if(f){// Resubmit filter on clear
// So we can avoid wrong tab link retaining search value
m.addEventListener("search",t=>{var{value:e}=t.currentTarget||{};if(/\S+/.test(e)==false){window.location=y("search")}});// Assign search value to normal form submission
f.onsubmit=t=>{t.preventDefault();var e=m.value;window.location=b("search",e)}}/**
	 * onclick apply button show checkbox select message
	 * if not selected
	 */var p=document.getElementById("tutor-admin-bulk-action-btn");var _=document.querySelector(".tutor-bulk-modal-disabled");if(p){p.onclick=()=>{var t=[];var e=document.querySelectorAll(".tutor-bulk-checkbox");for(var r of e){if(r.checked){t.push(r.value)}}if(t.length){_.setAttribute("id","tutor-bulk-confirm-popup")}else{tutor_toast(__("Warning","tutor"),__("Nothing was selected for bulk action.","tutor"),"error");if(_.hasAttribute("id")){_.removeAttribute("id")}}}}/**
	 * Onsubmit bulk form handle ajax request then reload page
	 */var h=document.getElementById("tutor-admin-bulk-action-form");if(h){h.onsubmit=t=>a(function*(){t.preventDefault();t.stopPropagation();var e=new FormData(h);var r=[];var o=document.querySelectorAll(".tutor-bulk-checkbox");for(var a of o){if(a.checked){r.push(a.value)}}if(!r.length){alert(__("Select checkbox for action","tutor"));return}e.set("bulk-ids",r);e.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);try{var n=document.querySelector("#tutor-confirm-bulk-action[data-tutor-modal-submit]");n.classList.add("is-loading");var i=yield fetch(window._tutorobject.ajaxurl,{method:"POST",body:e});n.classList.remove("is-loading");if(i.ok){var s=yield i.json();if(s.success||200===(s===null||s===void 0?void 0:s.status_code)){location.reload()}else{var{message:u=__("Something went wrong, please try again ","tutor")}=s.data||{};tutor_toast(__("Failed","tutor"),u,"error")}}}catch(t){console.log(t)}})()}/**
	 * onclick bulk action button show confirm popup
	 * on click confirm button submit bulk form
	 */var g=document.getElementById("tutor-confirm-bulk-action");if(g){g.onclick=()=>{var t=document.createElement("input");t.type="submit";h.appendChild(t);t.click();t.remove()}}function b(t,e){var r=new URL(window.location.href);var o=r.searchParams;o.set(t,e);o.set("paged",1);return r}function y(t){var e=new URL(window.location.href);var r=e.searchParams;r.delete(t);return e}/**
	 * Select all bulk checkboxes
	 *
	 * @since v2.0.0
	 */var w=document.querySelector("#tutor-bulk-checkbox-all");if(w){w.addEventListener("click",()=>{var t=document.querySelectorAll(".tutor-bulk-checkbox");t.forEach(t=>{if(w.checked){t.checked=true}else{t.checked=false}})})}/**
	 * Delete course delete
	 */var q=document.querySelectorAll(".tutor-admin-course-delete");for(var k of q){k.onclick=t=>{var e=t.currentTarget.dataset.id;if(i){i.elements.action.value="tutor_course_delete";i.elements.id.value=e}}}/**
	 * Handle permanent delete action
	 *
	 * @since 3.0.0
	 */var S=document.querySelectorAll(".tutor-delete-permanently");for(var x of S){x.onclick=t=>{var e=t.currentTarget.dataset.id;var r=t.currentTarget.dataset.action;if(i){i.elements.action.value=r;i.elements.id.value=e}}}/**
	 * Handle common confirmation form
	 *
	 * @since v.2.0.0
	 */if(i){i.onsubmit=t=>a(function*(){t.preventDefault();var e=new FormData(i);//show loading
    var r=i.querySelector("[data-tutor-modal-submit]");r.classList.add("is-loading");var a=yield n(e);//hide modal
    if(o.classList.contains("tutor-is-active")){o.classList.remove("tutor-is-active")}if(a.ok){var s=yield a.json();r.classList.remove("is-loading");if(s){if(typeof s==="object"&&s.success){tutor_toast(__("Delete","tutor"),s.data,"success");location.reload(true)}else if(typeof s==="object"&&s.success===false){tutor_toast(__("Failed","tutor"),s.data,"error")}else{tutor_toast(__("Delete","tutor"),__("Successfully deleted ","tutor"),"success");location.reload()}}else{tutor_toast(__("Failed","tutor"),__("Delete failed ","tutor"),"error")}}})()}});// EXTERNAL MODULE: ./assets/react/admin-dashboard/segments/lib.js
var i=r(83650);// CONCATENATED MODULE: ./assets/react/helper/utils.js
function s(){return a(function*(){try{var t=yield fetch("".concat(_tutorobject.tutor_url,"/assets/json/countries.json"));if(!t.ok){throw new Error("Failed to fetch countries: ".concat(t.status," ").concat(t.statusText))}return yield t.json()}catch(t){console.error("Error fetching countries:",t);return[]}})()}function u(){return/Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent)}// EXTERNAL MODULE: ./assets/react/front/_select_dd_search.js
var c=r(4545);// CONCATENATED MODULE: ./assets/react/helper/tutor-formdata.js
/**
 * Prepare custom form data, while setting form data
 * it will also set tutor nonce field.
 * 
 * @since v2.1.0
 * 
 * @param formId  form id attribute
 * @param data array of objects of form elements. Key value par
 * like: [{name: 'john doe'}, {age: 100}]
 * 
 * @return mixed formData on success, false on any error
 */if(!window.tutor_get_nonce_data){window.tutor_get_nonce_data=function(t){var e=window._tutorobject||{};var r=e.nonce_key||"";var o=e[r]||"";if(t){return{key:r,value:o}}return{[r]:o}}}function l(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:[];var e=new FormData;t.forEach(t=>{for(var[r,o]of Object.entries(t)){e.set(r,o)}});e.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);return e}/* ESM default export */const d=l;// CONCATENATED MODULE: ./assets/react/front/course/_archive.js
var v=["keyword","course_order","tutor-course-filter-type","tutor-course-filter-level","tutor-course-filter-tag","tutor-course-filter-category","tutor-course-filter-price","course_filter","supported_filters","current_page","action"];var f=t=>{var e=function(e){var o=Array.isArray(t[e]);var a=o?e+"[]":e;var n=o?t[e]:[t[e]];n.forEach(t=>{if(typeof t!="object"){r.searchParams.append(a,t)}})};var r=new URL(window.location.origin+window.location.pathname);var o=m();// Include other params except tutors
for(var a in o){if(v.indexOf(a)==-1){r.searchParams.append(a,o[a])}}// Add currently used tutor params to the state
for(var n in t)e(n);window.history.pushState({},"",r)};var m=()=>{var t={};new URL(window.location).searchParams.forEach(function(e,r){if(r.slice(-2)=="[]"){var o=r.slice(0,-2);!t[o]?t[o]=[]:0;!Array.isArray(t[o])?t[o]=[t[o]]:0;t[o].push(e)}else{t[r]=e}});return t};var p=t=>{var e=function(e){var o=r[e];var a=t.find('[name="'+e+'"]');if(a.eq(0).attr("type")=="checkbox"){var n=!Array.isArray(o)?[o]:o;a.each(function(){var t=n.indexOf(window.jQuery(this).attr("value"))>-1;window.jQuery(this).prop("checked",t)})}else{a.val(o)}};var r=m();t.find('[type="checkbox"]').prop("checked",false);t.find('[type="text"], select').val("");// Loop through filter params array and change element state like check/uncheck/field value based on the filter
for(var o in r)e(o)};window.jQuery(document).ready(t=>{var{__}=window.wp.i18n;/**
     * Manage course filter
     *
     * @since  v.1.7.2
     */var e=t("[tutor-course-filter] form");if(!e.length){return}var r=t("[tutor-course-list-container]");var o=t(".tutor-courses-wrap").data("tutor_courses_meta")||{};var i={};// Sidebar checkbox value change
e.on("submit",function(t){t.preventDefault()}).find("input,select").on("change",function(t){s()});p(e);window.addEventListener("popstate",()=>{p(e);s(false,true)});var s=function(){var a=arguments.length>0&&arguments[0]!==void 0?arguments[0]:true,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:false;var s=m();var u=Object.assign(e.serializeObject(),i,o);u.current_page=n&&s.current_page?s.current_page:1;u.action="tutor_course_filter_ajax";if(a){f(u)}r.html('<div class="tutor-spinner-wrap"><span class="tutor-spinner" area-hidden="true"></span></div>');e.find("[action-tutor-clear-filter]").closest(".tutor-widget-course-filter").removeClass("tutor-d-none");if(!("category"in u.supported_filters)){var c="tutor-course-filter-category";var l=Object.keys(s).filter(t=>t.includes(c));if(l.length>0){var d=[];l.forEach(t=>{d.push(s[t])});u["tutor-course-filter-category"]=[...new Set(d)]}else{u["tutor-course-filter-category"]=JSON.parse(t("#course_filter_categories").val())}}var v="tutor-course-filter-exclude-ids";var p=Object.keys(s).filter(t=>t.includes(v));var _=[];if(p.length>0){p.forEach(t=>{_.push(s[t])});u["tutor-course-filter-exclude-ids"]=[...new Set(_)]}else{if(t("#course_filter_exclude_ids").length){u["tutor-course-filter-exclude-ids"]=JSON.parse(t("#course_filter_exclude_ids").val())}}var h="tutor-course-filter-post-ids";var g=Object.keys(s).filter(t=>t.includes(h));var b=[];if(g.length>0){g.forEach(t=>{b.push(s[t])});u["tutor-course-filter-post-ids"]=[...new Set(b)]}else{if(t("#course_filter_post_ids").length){u["tutor-course-filter-post-ids"]=JSON.parse(t("#course_filter_post_ids").val())}}t.ajax({url:window._tutorobject.ajaxurl,type:"POST",data:u,success:function t(t){if(!t.success){r.html(__("Could not load courses","tutor"));return}r.html(t.data.html).find("nav").css("display","flex");window.dispatchEvent(new Event(_tutorobject.content_change_event))}})};// Course Filter on Phone
t("[tutor-toggle-course-filter]").on("click",function(e){e.preventDefault();t("body").toggleClass("tutor-course-filter-open");if(t(".tutor-course-filter-backdrop").length==0){t("body").append(t('<div class="tutor-course-filter-backdrop" area-hidden="true"></div>').hide().fadeIn(150))}});t("[tutor-hide-course-filter]").on("click",function(e){e.preventDefault();t("body").removeClass("tutor-course-filter-open")});/**
     * Enroll student if user click on enroll course button
     * 
     * @since v2.1.0
     */var u=document.querySelectorAll(".tutor-course-list-enroll");u.forEach(t=>{t.onclick=t=>a(function*(){t.preventDefault();var e=__("Something went wrong, please try again!","tutor");var r=t.target;var o=[{action:"tutor_course_enrollment"},{course_id:r.dataset.courseId}];if(r.dataset.subscriptionEnrollment){o.push({tutor_subscription_enrollment:true})}var a=d(o);r.classList.add("is-loading");r.setAttribute("disabled",true);var i=yield n(a);if(i.ok){var s=yield i.json();var{success:u,data:c}=s;if(u){tutor_toast(__("Success","tutor"),c,"success");window.location.href=r.href}else{tutor_toast(__("Failed","tutor"),c?c:e,"error")}}else{tutor_toast(__("Error","tutor"),__(e),"error")}r.classList.remove("is-loading");r.removeAttribute("disabled")})()})});// Reusable for Instructor list filter
// EXTERNAL MODULE: ./assets/react/front/course/_lesson.js
var _=r(80922);// EXTERNAL MODULE: ./assets/react/front/course/_social-share.js
var h=r(23825);// CONCATENATED MODULE: ./assets/react/front/course/_spotlight.js
jQuery(document).ready(function(t){t(".tutor-sortable-list").sortable()});document.addEventListener("DOMContentLoaded",t=>{var{__,_x:e,_n:r,_nx:o}=wp.i18n;var i=document.querySelector(".tutor-lesson-sidebar.tutor-desktop-sidebar");var s=document.querySelector(".tutor-sidebar-toggle-anchor");if(i&&s){s.addEventListener("click",()=>{if(getComputedStyle(i).flex==="0 0 400px"){i.style.flex="0 0 0px";i.style.display="none"}else{i.style.display="block";i.style.flex="0 0 400px"}})}/**
	 * dynamically calcutate sidebarContent height from top
	 * and decrease sidebar height
	 */var u=document.querySelector(".tutor-sidebar-tabs-content");if(u){var c=u.getBoundingClientRect().top;u.style.height="calc(100vh - ".concat(c,"px)")}var l=function t(t){var e=document.querySelector(".tutor-desktop-sidebar-area");if(null!==e&&e.children.length<2){return}t.forEach(t=>{t.addEventListener("click",t=>{var e=t.currentTarget.parentNode.nextElementSibling;r(e);t.currentTarget.classList.add("active");var o=t.currentTarget.getAttribute("data-sidebar-tab");var a=e.querySelector("#"+o);a.classList.add("active");/**
				 * dynamically calcutate qnatabcontentrarea height from top
				 * and decrease it's height from 100vh
				 */var n=document.querySelector(".tutor-lessons-tab-area");var i=n.offsetHeight;if(o=="sidebar-qna-tab-content"){a.style.height="calc(100% - ".concat(i,"px)")}})});var r=function e(e){for(var r=0;r<t.length;r++){t[r].classList.remove("active")}var o=e.querySelectorAll(".tutor-lesson-sidebar-tab-item");for(var a=0;a<o.length;a++){o[a].classList.remove("active")}}};var d=document.querySelectorAll(".tutor-desktop-sidebar-area .tutor-sidebar-tab-item");var v=document.querySelectorAll(".tutor-mobile-sidebar-area .tutor-sidebar-tab-item");if(d){l(d)}if(v){l(v)}/* end of sidetab tab *//* comment text-area focus arrow style */var f=document.querySelectorAll(".tutor-comment-textarea textarea");if(f){f.forEach(t=>{t.addEventListener("focus",()=>{t.parentElement.classList.add("is-focused")});t.addEventListener("blur",()=>{t.parentElement.classList.remove("is-focused")})})}/* comment text-area focus arrow style */function m(){var t=document.querySelectorAll(".tutor-comments-list.tutor-parent-comment");var e=document.querySelector(".tutor-comment-box.tutor-reply-box");if(t){[...t].forEach(t=>{var r=t.querySelectorAll(".tutor-comments-list.tutor-child-comment");var o=t.querySelector(".tutor-comment-line");var a=r.length;if(r[a-1]){var n=r[a-1].clientHeight;var i=n+e.clientHeight+20-25+50;o.style.setProperty("height","calc(100% - ".concat(i,"px)"))}})}}m();window.addEventListener(_tutorobject.content_change_event,m);/* commenting */// quiz drag n drop functionality
var p=document.querySelectorAll(".tutor-draggable > div");var _=document.querySelectorAll(".tutor-dropzone");p.forEach(t=>{t.addEventListener("dragstart",k);t.addEventListener("dragend",S)});p.forEach(t=>{["touchstart","touchmove","touchend"].forEach(function(e){t.addEventListener(e,b)})});_.forEach(t=>{t.addEventListener("dragover",x);t.addEventListener("dragenter",L);t.addEventListener("dragleave",j);t.addEventListener("drop",E)});var h=null;var g=0;function b(t){t.preventDefault();var{type:e}=t;if(e==="touchstart"){this.classList.add("tutor-dragging");w()}else if(e==="touchmove"){var r=t.target.closest(".tutor-dragging");var o=document.querySelector(".tutor-drag-copy");if(r){var a=r.getBoundingClientRect();var n=t.touches[0].clientY;var i=t.touches[0].clientX;var s=100;var u=40;var c=window.innerHeight;var l=c-n;var d=n;g=0;if(l<s){g=q(s,l,u)}else if(d<s){g=-q(s,d,u)}if(!o){o=r.cloneNode(true);o.classList.add("tutor-drag-copy");r.parentNode.appendChild(o)}o.style.position="fixed";o.style.left=i-o.clientWidth/2+"px";o.style.top=n-o.clientHeight/2+"px";o.style.zIndex="9999";o.style.opacity="0.5";o.style.width=a.width+"px";o.style.height=a.height+"px"}}else if(e==="touchend"){var v=document.querySelector(".tutor-drag-copy");if(v){v.remove();var f=typeof t.originalEvent==="undefined"?t:t.originalEvent;var m=f.touches[0]||f.changedTouches[0];var[p,_]=[m.clientX,m.clientY];var h=document.elementFromPoint(p,_);if(h.classList.contains("tutor-dropzone")||h.closest(".tutor-dropzone")){if(!h.classList.contains("tutor-dropzone")){h=h.closest(".tutor-dropzone")}var b=v.querySelector("input");var k=b.dataset.name;var S=document.createElement("input");S.type="text";S.setAttribute("value",b.value);S.setAttribute("name",k);/**
					 * Selecting a correct option after an incorrect fails in mobile issue fixed.
					 * 
					 * @since 3.2.0
					 */var x=h.querySelector("input");if(x){x.remove()}h.appendChild(S);var L=v.querySelector(".tutor-dragging-text-conent").textContent;h.querySelector(".tutor-dragging-text-conent").textContent=L;h.querySelector(".tutor-dragging-text-conent").classList.add("tutor-color-black");this.classList.remove("tutor-dragging")}}y()}}function y(){clearInterval(h);h=null}function w(){if(!h){h=setInterval(()=>{window.scrollBy(0,g)},60)}}function q(t,e,r){var o=(t-e)/t*r;return Math.max(o,0)}function k(){this.classList.add("tutor-dragging")}function S(){this.classList.remove("tutor-dragging")}function x(t){this.classList.add("tutor-drop-over");t.preventDefault()}function L(){}function j(){this.classList.remove("tutor-drop-over")}function E(){var t=document.querySelector(".tutor-quiz-border-box.tutor-dragging");if(this.querySelector("input")){this.querySelector("input").remove()}var e=t.querySelector("input");var r=e.dataset.name;var o=document.createElement("input");o.type="text";o.setAttribute("value",e.value);o.setAttribute("name",r);this.appendChild(o);var a=t.querySelector(".tutor-dragging-text-conent").textContent;this.querySelector(".tutor-dragging-text-conent").textContent=a;this.querySelector(".tutor-dragging-text-conent").classList.add("tutor-color-black");this.classList.remove("tutor-drop-over")}// tutor assignment file upload
var C=document.getElementById("tutor-assignment-file-upload");if(C){C.addEventListener("change",z)}function z(){var t;var e=[...C.files].reduce((t,e)=>t+e.size,0);// byte
var r=parseInt((t=document.querySelector('input[name="tutor_assignment_upload_limit"]'))===null||t===void 0?void 0:t.value)||0;var o="";var a=window._tutorobject.assignment_max_file_allowed;var n=document.querySelectorAll("#tutor-student-assignment-edit-file-preview .tutor-instructor-card").length;var i=a-n;if(C.files.length>i){C.value=null;tutor_toast(__("Warning","tutor"),__("Max ".concat(a," file allowed to upload"),"tutor"),"error");return}if(e>r){C.value=null;tutor_toast(__("Warning","tutor"),__("File size exceeds maximum limit ".concat(Math.floor(r/1e6)," MB."),"tutor"),"error");return}if("files"in C){if(C&&C.files.length==0){o="Select one or more files."}else{if(C.files.length>i){tutor_toast(__("Warning","tutor"),__("Max ".concat(a," file allowed to upload"),"tutor"),"error")}var s="";var u=document.querySelector(".tutor-asisgnment-upload-file-preview");var c=document.getElementById("tutor-student-assignment-edit-file-preview");for(var l=0;l<i;l++){var d=C.files[l];if(!d){continue}var v=c?"tutor-col-sm-5 tutor-py-16 tutor-mr-16":"";s+='<div class="tutor-instructor-card '.concat(v,'">\n                                    <div class="tutor-icard-content">\n                                        <div class="tutor-fs-6 tutor-color-secondary">\n                                            ').concat(d.name,'\n                                        </div>\n                                        <div class="tutor-fs-7">Size: ').concat(d.size,'</div>\n                                    </div>\n                                    <div onclick="(() => {\n										this.closest(\'.tutor-instructor-card\').remove();\n									})()" class="tutor-attachment-file-close tutor-iconic-btn tutor-iconic-btn-outline flex-center">\n                                        <span class="tutor-icon-times"></span>\n                                    </div>\n                                </div>')}if(u){u.innerHTML=s}if(c){c.insertAdjacentHTML("beforeend",s)}}}}//remove file
var T=document.querySelectorAll(".tutor-attachment-file-close a");T.forEach(t=>{t.onclick=t=>a(function*(){t.preventDefault();var e=t.currentTarget;var r=e.dataset.name;var o=e.dataset.id;var a=new FormData;a.set("action","tutor_remove_assignment_attachment");a.set("assignment_comment_id",o);a.set("file_name",r);a.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);var i=e.querySelector("span");t.target.classList.add("is-loading");var s=yield n(a);if(s.ok){var u=yield s.json();if(!u){tutor_toast(__("Warning","tutor"),__("Attachment remove failed","tutor"),"error")}else{e.closest(".tutor-instructor-card").remove()}}else{alert(s.statusText);t.target.classList.remove("is-loading")}})()})});// EXTERNAL MODULE: ./assets/react/front/course/_spotlight-quiz.js
var g=r(90521);// EXTERNAL MODULE: ./assets/react/front/course/_spotlight-quiz-timing.js
var b=r(63023);// EXTERNAL MODULE: ./assets/react/front/course/_wishlist.js
var y=r(12155);// EXTERNAL MODULE: ./assets/react/front/course/_woocommerce.js
var w=r(53579);// CONCATENATED MODULE: ./assets/react/front/course/index.js
window.jQuery(document).ready(t=>{// Login require on enrol purchase click
t(document).on("click",".tutor-course-entry-box-login button, .tutor-course-entry-box-login a, .tutor-open-login-modal",function(e){e.preventDefault();var r=t(this).data("login_url")||t(this).closest(".tutor-course-entry-box-login").data("login_url");if(r){window.location.assign(r)}else{t(".tutor-login-modal").addClass("tutor-is-active")}});/**
     * Tutor password protected course.
     * 
     * @since v.3.0.0
     */var e=document.querySelector(".tutor-password-protected-course");if(e){// Disable page scrolling when password protected course modal is active.
var r=document.querySelector("body");r.style.overflow="hidden";// Hide and show password on checkbox click.
var o=e.querySelector('input[type="password"]');var a=e.querySelector('input[type="checkbox"]');a.addEventListener("change",function(){if(a.checked){o.type="text"}else{o.type="password"}})}/**
     * Replace UTC date time to local date time
     * 
     * @since v.3.3.0
     */function n(){var t=document.querySelectorAll(".tutor-utc-date-time");if(t.length>0&&wp.date){var e=wp.date.getSettings();var r=e.formats.date;var o=e.formats.time;var a="".concat(r,", ").concat(o);t.forEach(t=>{try{var e=t.textContent.trim();var r=new Date("".concat(e," UTC"));if(!isNaN(r)){t.textContent=wp.date.dateI18n(a,r,Intl.DateTimeFormat().resolvedOptions().timeZone)}else{console.warn('Invalid UTC date: "'.concat(e,'"'))}}catch(t){console.log(t)}})}}n();window.addEventListener("tutor_content_changed_event",()=>{n()})});// EXTERNAL MODULE: ./assets/react/front/dashboard/mobile-nav.js
var q=r(20193);// EXTERNAL MODULE: ./assets/react/front/dashboard/withdrawal.js
var k=r(44789);// EXTERNAL MODULE: ./assets/react/front/dashboard/settings/profile.js
var S=r(48621);// EXTERNAL MODULE: ./assets/react/front/dashboard/settings/passowrd-reset.js
var x=r(35852);// CONCATENATED MODULE: ./assets/react/front/dashboard/settings/billing.js
document.addEventListener("DOMContentLoaded",function(){var{__}=wp.i18n;var t=__("Something went wrong, please try again","tutor");var e=document.querySelector("#user_billing_form");if(e){var r=e.querySelector('button[type="submit"]');e.addEventListener("submit",function(e){return a(function*(){e.preventDefault();var o=new FormData(e.target);try{r.setAttribute("disabled","disabled");r.classList.add("is-loading");var a=yield n(o);var{status_code:i,message:s=t}=yield a.json();if(i===200){tutor_toast(__("Success","tutor"),s,"success")}else{tutor_toast(__("Failed","tutor"),s,"error")}}catch(e){tutor_toast(__("Failed","tutor"),t,"error")}finally{r.removeAttribute("disabled");r.classList.remove("is-loading")}})()})}});// EXTERNAL MODULE: ./assets/react/front/dashboard/index.js
var L=r(11602);// CONCATENATED MODULE: ./assets/react/front/dashboard.js
// EXTERNAL MODULE: ./assets/react/front/dashboard/export-csv.js
var j=r(6402);// CONCATENATED MODULE: ./assets/react/front/pages/billing.js
document.addEventListener("DOMContentLoaded",()=>a(function*(){var{__}=wp.i18n;var t=document.querySelector("[name=billing_country]");if(t){var e=yield s();t.addEventListener("change",t=>{var r;var o=t.target.value;var a=(r=e.find(t=>t.name===o))===null||r===void 0?void 0:r.states;var n=document.querySelector("[name=billing_state]");// Clear current state options
    if(a&&a.length>0){n.innerHTML="";// Populate state dropdown with new states
    a.forEach(function(t){var e=document.createElement("option");e.value=t.name;e.textContent=t.name;n.appendChild(e)})}else{n.innerHTML='<option value="">'.concat(__("N/A","tutor"),"</option>")}})}})());// CONCATENATED MODULE: ./assets/react/front/pages/cart.js
document.addEventListener("DOMContentLoaded",function(){var{__}=wp.i18n;var t=__("Something went wrong, please try again","tutor");// Add to cart functionalities
document.addEventListener("click",e=>a(function*(){var r=e.target.closest(".tutor-native-add-to-cart");if(r){var o=d([{action:"tutor_add_course_to_cart",course_id:r.dataset.courseId}]);var a=document.body.classList.contains("single-courses")||document.body.classList.contains("single-course-bundle");try{r.setAttribute("disabled","disabled");r.classList.add("is-loading");var i=yield n(o);var{status_code:s,data:u,message:c=t}=yield i.json();if(s===201){tutor_toast(__("Success","tutor"),c,"success");var l;var v='<a data-cy="tutor-native-view-cart" href="'.concat((l=u===null||u===void 0?void 0:u.cart_page_url)!==null&&l!==void 0?l:"#",'" class="tutor-btn tutor-btn-outline-primary ').concat(a?"tutor-btn-lg tutor-btn-block":"tutor-btn-md"," ").concat(!(u===null||u===void 0?void 0:u.cart_page_url)?"tutor-cart-page-not-configured":"",'">').concat(__("View Cart","tutor"),"</a>");r.parentElement.innerHTML=v;// Create a custom event with cart count
    var f=new CustomEvent("tutorAddToCartEvent",{detail:{cart_count:u===null||u===void 0?void 0:u.cart_count}});// Dispatch the custom cart event
    document.dispatchEvent(f)}else{tutor_toast(__("Failed","tutor"),c,"error")}}catch(e){tutor_toast(__("Failed","tutor"),t,"error")}finally{r.removeAttribute("disabled");r.classList.remove("is-loading")}}})());// Remove course from card
var e=document.querySelector(".tutor-cart-page");if(e){document.addEventListener("click",e=>a(function*(){var r=e.target.closest(".tutor-cart-remove-button");if(r){var o=d([{action:"tutor_delete_course_from_cart",course_id:r.dataset.courseId}]);try{r.setAttribute("disabled","disabled");r.classList.add("is-loading");var a=yield n(o);var{status_code:i,data:s,message:u=t}=yield a.json();if(i===200){document.querySelector(".tutor-cart-page-wrapper").parentElement.innerHTML=s===null||s===void 0?void 0:s.cart_template;tutor_toast(__("Success","tutor"),u,"success");// Trigger a custom event with cart count
    var c=new CustomEvent("tutorRemoveCartEvent",{detail:{cart_count:s===null||s===void 0?void 0:s.cart_count}});// Dispatch the custom cart event
    document.dispatchEvent(c)}else{tutor_toast(__("Failed","tutor"),u,"error")}}catch(e){tutor_toast(__("Failed","tutor"),t,"error")}finally{r.removeAttribute("disabled");r.classList.remove("is-loading")}}})())}// Display toast if cart page is not configured.
document.addEventListener("click",t=>{if(t.target.classList.contains("tutor-cart-page-not-configured")){t.preventDefault();tutor_toast(__("Error!","tutor"),__("Cart page is not configured.","tutor"),"error")}});// Display toast if checkout page is not configured.
document.addEventListener("click",t=>{if(t.target.classList.contains("tutor-checkout-page-not-configured")){t.preventDefault();tutor_toast(__("Error!","tutor"),__("Checkout page is not configured.","tutor"),"error")}})});// CONCATENATED MODULE: ./assets/react/front/pages/checkout.js
document.addEventListener("DOMContentLoaded",()=>{var{__}=wp.i18n;var t=__("Something went wrong, please try again","tutor");var e=document.querySelector(".tutor-checkout-page");if(e){var r=document.querySelector(".tutor-payment-method-wrapper");var o=document.querySelector("#tutor-checkout-pay-now-button");var i=document.querySelectorAll(".tutor-checkout-payment-item");var s=document.querySelector("input[name=payment_type]");/**
         * Get checkout JSON object.
         *
         * @since 3.6.0
         *
         * @returns {object} JSON object.
         */function u(){var t;var e=(t=document.querySelector("#checkout_data"))===null||t===void 0?void 0:t.value;return JSON.parse(e)}/**
         * Determines if tax is managed by Tutor (not the payment gateway) 
         *
         * @since 3.6.0
         *
         * @param {string} paymentMethodName - The name of the payment method (paypal, stripe, paddle, etc).
         *
         * @returns {boolean}
         */function c(t){var e=["paddle"];return!e.includes(t.toLowerCase())}/**
         * Determine tax info will be shown or hide.
         * 
         * @since 3.6.0
         *
         * @param {string} paymentMethodName payment method name.
         *
         * @returns {void}
         */function l(t){var e=document.querySelector(".tutor-checkout-tax-amount");var r=document.querySelectorAll(".tutor-checkout-incl-tax-label");var o=document.querySelector(".tutor-checkout-grand-total");var a=u();if(c(t)){o.innerHTML=a.formatted_total_price;r.forEach(t=>t.classList.remove("tutor-d-none"));e===null||e===void 0?void 0:e.classList.remove("tutor-d-none")}else{o.innerHTML=a.formatted_total_price_without_tax;r.forEach(t=>t.classList.add("tutor-d-none"));e===null||e===void 0?void 0:e.classList.add("tutor-d-none")}}// Handle payment method selection.
document.addEventListener("click",e=>a(function*(){if(e.target.closest(".tutor-checkout-payment-options")){var a=document.querySelector(".tutor-checkout-payment-options");var i=a.querySelectorAll("label");// Remove active class.
    i.forEach(t=>t.classList.remove("active"));// Add active class to the selected option.
    var c=e.target.closest("label");c.classList.add("active");s.value=c.dataset.paymentType;var d=c.firstElementChild.value;l(d);var f=document.querySelector(".tutor-payment-instructions");if(f){var m=c.querySelector(".tutor-payment-item-instructions");if(m){f.classList.remove("tutor-d-none");f.innerHTML=m.innerHTML}else{f.classList.add("tutor-d-none")}}}// Handle toggle coupon form button click.
    if(e.target.closest("#tutor-toggle-coupon-button")){var p=document.querySelector(".tutor-apply-coupon-form");var _=p===null||p===void 0?void 0:p.querySelector("input");if(p.classList.contains("tutor-d-none")){p.classList.remove("tutor-d-none");_.focus()}else{p.classList.add("tutor-d-none")}}// Handle apply coupon button.
    if(e.target.closest("#tutor-apply-coupon-button")){var h;var b=new URL(window.location.href);var y=b.searchParams.get("plan");var w=(h=document.querySelector(".tutor-apply-coupon-form input"))===null||h===void 0?void 0:h.value;var q=document.querySelector(".tutor-apply-coupon-form button");if(w.length===0){tutor_toast(__("Failed","tutor"),__("Please add a coupon code.","tutor"),"error");return}var k=new FormData;k.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);k.set("action","tutor_apply_coupon");k.set("coupon_code",w);k.set("object_ids",q.dataset.objectIds);if(y){k.set("plan",y)}try{q.setAttribute("disabled","disabled");q.classList.add("is-loading");var S=yield n(k);var{status_code:x,data:L,message:j=t}=yield S.json();if(x===200){tutor_toast(__("Success","tutor"),j,"success");yield v(w,null,null);if(!L.total_price&&L.order_type==="single_order"){var E;r.classList.add("tutor-d-none");o.innerHTML=(E=u())===null||E===void 0?void 0:E.pay_now_btn_text;r.insertAdjacentHTML("beforeend","<input type='hidden' name='payment_method' value='free' id=\"tutor-temp-payment-method\"/>")}}else{tutor_toast(__("Failed","tutor"),j,"error")}}catch(e){tutor_toast(__("Failed","tutor"),t,"error")}finally{q.removeAttribute("disabled");q.classList.remove("is-loading")}}// Handle coupon remove button click.
    if(e.target.closest("#tutor-checkout-remove-coupon")){var C,z,T;document.querySelector("input[name=coupon_code]").value="-1";document.querySelector("#tutor-checkout-remove-coupon").classList.add("is-loading");yield v("-1",null,null);var A=(C=document.querySelector("input[name=payment_method]:checked"))===null||C===void 0?void 0:C.value;if(A){l(A)}r.classList.remove("tutor-d-none");o.innerHTML=(z=u())===null||z===void 0?void 0:z.pay_now_btn_text;(T=document.getElementById("tutor-temp-payment-method"))===null||T===void 0?void 0:T.remove();g()}})());// If only one payment available, keep selected.
g();// Apply coupon on enter coupon field.
document.addEventListener("keydown",t=>{if(t.key==="Enter"&&t.target.closest("input[name=coupon_code]")){t.preventDefault();var e=t.target.parentNode.querySelector("#tutor-apply-coupon-button");e===null||e===void 0?void 0:e.click()}});// Validate checkout form.
var d=document.getElementById("tutor-checkout-form");d===null||d===void 0?void 0:d.addEventListener("submit",function(t){t.preventDefault();var e=u();var r=new FormData(t.target);if(e.payment_method_required&&!r.get("payment_method")){tutor_toast(__("Error","tutor"),__("Please select a payment method.","tutor"),"error");return}var o=document.getElementById("tutor-checkout-pay-now-button");o.classList.add("is-loading");o.textContent=__("Processing","tutor");o.setAttribute("disabled",true);this.submit()});/**
         * Update checkout data.
         * 
         * @since 3.3.0
         * 
         * @param {string} couponCode coupon code.
         * @param {string} billingCountry Billing country.
         * @param {string} billingState Billing state.
         */function v(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null,r=arguments.length>2&&arguments[2]!==void 0?arguments[2]:null;return a(function*(){var o=new URL(window.location.href);var a=o.searchParams.get("plan");var i=o.searchParams.get("course_id");var s=o.searchParams.get("order_id");var u=new FormData;u.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);u.set("action","tutor_get_checkout_html");u.set("coupon_code",t);if(e){u.set("billing_country",e)}if(r){u.set("billing_state",r)}if(a){u.set("plan",a)}if(i){u.set("course_id",i)}if(s){u.set("order_id",s)}var c=yield n(u);var l=yield c.json();var d=document.querySelector("[tutor-checkout-details]");if(d){d.innerHTML=l.data}})()}/**
         * Handle tax calculation on country and state change.
         * 
         * @since 3.0.0
         */var f=document.querySelector("[name=billing_country]");var m=document.querySelector("[name=billing_state]");var p='<span class="tutor-btn is-loading tutor-checkout-spinner"></span>';function _(t){return a(function*(){t.set(window.tutor_get_nonce_data(true).key,window.tutor_get_nonce_data(true).value);t.set("action","tutor_save_billing_info");var e=yield n(t);var r=yield e.json();return r})()}var h=(t,e)=>{if("show"===e){var r;t===null||t===void 0?void 0:t.setAttribute("disabled","disabled");t===null||t===void 0?void 0:(r=t.closest(".tutor-position-relative"))===null||r===void 0?void 0:r.insertAdjacentHTML("beforeend",p)}else{var o,a;t===null||t===void 0?void 0:t.removeAttribute("disabled");t===null||t===void 0?void 0:(a=t.closest(".tutor-position-relative"))===null||a===void 0?void 0:(o=a.querySelector(".tutor-checkout-spinner"))===null||o===void 0?void 0:o.remove()}};f===null||f===void 0?void 0:f.addEventListener("change",t=>a(function*(){var e=document.querySelector("[name=coupon_code]");var r=t.target.value;var o=(e===null||e===void 0?void 0:e.value)?e.value:"";if(r){h(t.target,"show");var a=new FormData;a.set("billing_country",r);yield _(a);yield v(o,f.value,m.value);h(t.target,"hide")}})());m===null||m===void 0?void 0:m.addEventListener("change",t=>a(function*(){var e=document.querySelector("[name=coupon_code]");var r=f.value;var o=t.target.value;var a=(e===null||e===void 0?void 0:e.value)?e.value:"";if(o){h(t.target,"show");var n=new FormData;n.set("billing_country",r);n.set("billing_state",o);yield _(n);yield v(a,f.value,m.value);h(t.target,"hide")}})());/**
         * Handles the selection of a single payment option.
         * 
         * @returns {void}
         * @since 3.5.0
         */function g(){var t=u();if(!t.payment_method_required){return}// If only one payment available, keep selected.
if(i.length===1){i[0].classList.add("active");i[0].querySelector("input[name=payment_method]").checked=true;s.value=i[0].dataset.paymentType;l(i[0].firstElementChild.value);var e=i[0].querySelector(".tutor-payment-item-instructions");if(e){document.querySelector(".tutor-payment-instructions").classList.remove("tutor-d-none");document.querySelector(".tutor-payment-instructions").innerHTML=e.innerHTML}}}}});// EXTERNAL MODULE: ./assets/react/front/pages/course-landing.js
var E=r(1838);// EXTERNAL MODULE: ./assets/react/front/pages/instructor-list-filter.js
var C=r(39356);// CONCATENATED MODULE: ./assets/react/front/tutor-front.js
/**
 * Codes from this file should be decentralized according to relavent file/folder structure.
 * It's a legacy file.
 */readyState_complete(()=>{Object.entries(document.getElementsByTagName("a")).forEach(t=>{var e=t[1].getAttribute("href");if((e===null||e===void 0?void 0:e.includes("/logout"))||(e===null||e===void 0?void 0:e.includes("logout"))){t[1].setAttribute("data-no-instant","")}})});jQuery(document).ready(function(t){"use strict";/**
	 * wp.i18n translatable functions
	 * @since 1.9.0
	 */var{__,_x:r,_n:o,_nx:a,sprintf:n}=wp.i18n;/**
	 * Initiate Select2
	 * @since v.1.3.4
	 */if(jQuery().select2){t(".tutor_select2").select2({escapeMarkup:function t(t){return t}})}//END: select2
/*!
	 * jQuery UI Touch Punch 0.2.3
	 *
	 * Copyright 2011–2014, Dave Furfero
	 * Dual licensed under the MIT or GPL Version 2 licenses.
	 *
	 * Depends:
	 *  jquery.ui.widget.js
	 *  jquery.ui.mouse.js
	 */!function(t){function e(t,e){if(!(t.originalEvent.touches.length>1)){t.preventDefault();var r=t.originalEvent.changedTouches[0],o=document.createEvent("MouseEvents");o.initMouseEvent(e,!0,!0,window,1,r.screenX,r.screenY,r.clientX,r.clientY,!1,!1,!1,!1,0,null),t.target.dispatchEvent(o)}}if(t.support.touch="ontouchend"in document,t.support.touch){var r,o=t.ui.mouse.prototype,a=o._mouseInit,n=o._mouseDestroy;o._touchStart=function(t){var o=this;!r&&o._mouseCapture(t.originalEvent.changedTouches[0])&&(r=!0,o._touchMoved=!1,e(t,"mouseover"),e(t,"mousemove"),e(t,"mousedown"))},o._touchMove=function(t){r&&(this._touchMoved=!0,e(t,"mousemove"))},o._touchEnd=function(t){r&&(e(t,"mouseup"),e(t,"mouseout"),this._touchMoved||e(t,"click"),r=!1)},o._mouseInit=function(){var e=this;e.element.bind({touchstart:t.proxy(e,"_touchStart"),touchmove:t.proxy(e,"_touchMove"),touchend:t.proxy(e,"_touchEnd")}),a.call(e)},o._mouseDestroy=function(){var e=this;e.element.unbind({touchstart:t.proxy(e,"_touchStart"),touchmove:t.proxy(e,"_touchMove"),touchend:t.proxy(e,"_touchEnd")}),n.call(e)}}}(jQuery);/**
	 * END jQuery UI Touch Punch
	 */var i={ajaxurl:window._tutorobject.ajaxurl,nonce_key:window._tutorobject.nonce_key,played_once:false,max_seek_time:0,video_data:function e(){var e=t("#tutor_video_tracking_information").val();return e?JSON.parse(e):{}},track_player:function r(){var r=this;if(typeof Plyr!=="undefined"){var o;var a=r.video_data();var n=new Plyr(this.player_DOM,{keyboard:{focused:r.isRequiredPercentage()?false:true,global:false},listeners:e({},r.isRequiredPercentage()&&{seek(t){var e=r.getTargetTime(n,t);var o=n.currentTime;var a=o>r.max_seek_time?o:r.max_seek_time;// Disallow moving forward
if(e>a){t.preventDefault();tutor_toast(__("Warning","tutor"),__("Forward seeking is disabled","tutor"),"error");return false}return true}})});n.on("ready",function(e){var o=e.detail.plyr;var{best_watch_time:i=0}=a||{};/**
					 * Fix: Mobile Vimeo autoplay sound issue
					 * Always start muted on mobile to comply with autoplay policy.
					 * 
					 * @since 3.9.2
					 */if(n.provider==="vimeo"&&u()){try{n.muted=true;if(typeof n.mute==="function"){n.mute()}}catch(t){console.warn("Vimeo mute init failed:",t)}}if(_tutorobject.tutor_pro_url&&i>0){var s=Math.floor(i);var c=setTimeout(function(){if(n.playing!==true&&n.currentTime!==s){if(o.provider==="youtube"){o.embed.seekTo(i)}else{o.media.currentTime=s}}else{clearTimeout(c)}})}r.sync_time(o);// Set player to window and dispatch custom event if lesson single page
if(t(r.player_DOM).closest(".tutor-course-topic-single-body .tutor-video-player-wrapper").length){var l=new CustomEvent("tutorLessonPlayerReady",{detail:{player:o}});window.dispatchEvent(l);window.tutorLessonPlayer=n}});n.on("play",e=>{r.played_once=true;/**
					 * Unmute automatically after first user interaction
					 * Mobile browsers allow audio only after gesture.
					 * 
					 * @since 3.9.2
					 */if(n.provider==="vimeo"&&u()){try{n.muted=false;if(typeof n.unmute==="function"){n.unmute()}}catch(t){console.warn("Vimeo unmute on play failed:",t)}}// Send to tutor backend about video playing time in this interval
var a=10;var i=e.detail.plyr;o=setInterval(()=>{r.sync_time(i)},a*1e3);if(_tutorobject.tutor_pro_url&&n.provider==="youtube"){t(".plyr--youtube.plyr__poster-enabled .plyr__poster").css("opacity",0)}});n.on("pause",t=>{clearInterval(o);var e=t.detail.plyr;r.sync_time(e)});n.on("ended",function(e){clearInterval(o);var a=r.video_data();var i=e.detail.plyr;var s={is_ended:true};r.sync_time(i,s);if(a.autoload_next_course_content&&r.played_once){r.autoload_content()}if(_tutorobject.tutor_pro_url&&n.provider==="youtube"){t(".plyr--youtube.plyr__poster-enabled .plyr__poster").css("opacity",1)}})}},sync_time:function e(e,r){var o=this.video_data();if(!o){return}if(this.isRequiredPercentage()){this.enable_complete_lesson_btn(e)}//TUTOR is sending about video playback information to server.
var a={action:"sync_video_playback",currentTime:e.currentTime,duration:e.duration,post_id:o.post_id};a[this.nonce_key]=_tutorobject[this.nonce_key];var n=a;if(r){n=Object.assign(a,r)}t.post(this.ajaxurl,n);var i=o.best_watch_time>e.currentTime?o.best_watch_time:e.currentTime;if(i>this.max_seek_time){this.max_seek_time=i}},autoload_content:function e(){console.log("Autoloader called");var e=this.video_data().post_id;var r={action:"autoload_next_course_content",post_id:e};r[this.nonce_key]=_tutorobject[this.nonce_key];t.post(this.ajaxurl,r).done(function(t){console.log(t);if(t.success&&t.data.next_url){location.href=t.data.next_url}})},isRequiredPercentage:function t(){var t=this.video_data();if(!t){return false}var{strict_mode:e,control_video_lesson_completion:r,lesson_completed:o,is_enrolled:a}=t;if(_tutorobject.tutor_pro_url&&a&&!o&&e&&r){return true}return false},enable_complete_lesson_btn:function e(e){var r=t('button[name="complete_lesson_btn"]');var o=this.video_data();var a=this.getPercentage(Number(e.currentTime),Number(e.duration));if(a>=o.required_percentage){r.attr("disabled",false);r.next().remove()}},disable_complete_lesson_btn:function e(){var e=this.video_data();if(!e){return}var{best_watch_time:r,video_duration:o,required_percentage:a}=e;var i=this.getPercentage(Number(r),Number(o));if(i<a){var s=t('button[name="complete_lesson_btn"]');s.attr("disabled",true);s.wrap('<div class="tooltip-wrap"></div>');s.after(/* translators: %s is the required watch percentage (e.g., 80) */'<span class="tooltip-txt tooltip-bottom">'.concat(n(__("Watch at least %s%% to complete the lesson.","tutor"),e.required_percentage),"</span>"))}},getPercentage:function t(t,e){if(t>0&&e>0){return Math.round(t/e*100)}return 0},getTargetTime:function t(t,e){if(typeof e==="object"&&(e.type==="input"||e.type==="change")){return e.target.value/e.target.max*t.media.duration}else{return Number(e)}},init:function t(t){this.player_DOM=t;this.track_player();if(this.isRequiredPercentage()){this.disable_complete_lesson_btn()}}};/**
	 * Fire TUTOR video
	 * @since v.1.0.0
	 */t(".tutorPlayer").each(function(){i.init(this)});t(document).on("change keyup paste",".tutor_user_name",function(){t(this).val(s(t(this).val()))});function s(t){return t.toString().toLowerCase().replace(/\s+/g,"-")// Replace spaces with -
.replace(/[^\w\-]+/g,"")// Remove all non-word chars
.replace(/\-\-+/g,"-")// Replace multiple - with single -
.replace(/^-+/,"")// Trim - from start of text
.replace(/-+$/,"");// Trim - from end of text
}t(document).on("click",".tutor_question_cancel",function(e){e.preventDefault();t(".tutor-add-question-wrap").toggle()});// Quiz Review : Tooltip
t(".tooltip-btn").on("hover",function(e){t(this).toggleClass("active")});// tutor course content accordion
/**
	 * Toggle topic summery
	 * @since v.1.6.9
	 */t(".tutor-course-title h4 .toggle-information-icon").on("click",function(e){t(this).closest(".tutor-topics-in-single-lesson").find(".tutor-topics-summery").slideToggle();e.stopPropagation()});t(".tutor-course-topic.tutor-active").find(".tutor-course-lessons").slideDown();t(".tutor-course-title").on("click",function(){var e=t(this).siblings(".tutor-course-lessons");t(this).closest(".tutor-course-topic").toggleClass("tutor-active");e.slideToggle()});t(document).on("click",".tutor-topics-title h3 .toggle-information-icon",function(e){t(this).closest(".tutor-topics-in-single-lesson").find(".tutor-topics-summery").slideToggle();e.stopPropagation()});// toggle topics sidebar
t(document).on("click","[tutor-course-topics-sidebar-toggler]",function(e){e.preventDefault();t(".tutor-course-single-content-wrapper").toggleClass("tutor-course-single-sidebar-hidden")});t("[tutor-course-topics-sidebar-offcanvas-toggler]").on("click",function(e){e.preventDefault();t(".tutor-course-single-content-wrapper").toggleClass("tutor-course-single-sidebar-open");t("body").toggleClass("tutor-overflow-hidden")});t("[tutor-hide-course-single-sidebar]").on("click",function(e){e.preventDefault();console.log("Hello");t(".tutor-course-single-content-wrapper").removeClass("tutor-course-single-sidebar-open");t("body").removeClass("tutor-overflow-hidden")});//@todo: to be removed
t(".tutor-tabs-btn-group a").on("click touchstart",function(e){e.preventDefault();var r=t(this);var o=r.attr("href");t(".tutor-lesson-sidebar-tab-item").hide();t(o).show();t(".tutor-tabs-btn-group a").removeClass("active");r.addClass("active")});/**
	 *
	 * @type {jQuery}
	 *
	 * Improved Quiz draggable answers drop accessibility
	 * Answers draggable wrap will be now same height.
	 *
	 * @since v.1.4.4
	 */var c=t(".quiz-draggable-rand-answers").length;if(c){t(".quiz-draggable-rand-answers").each(function(){var e=t(this);var r=e.height();e.css({height:r})})}/**
	 * Datepicker initiate
	 *
	 * @since v.1.1.2
	 */if(jQuery.datepicker){t(".tutor_report_datepicker").datepicker({dateFormat:"yy-mm-dd"})}/**
	 * Setting account for withdraw earning
	 *
	 * @since v.1.2.0
	 */t(document).on("submit","#tutor-withdraw-account-set-form",function(e){if(!e.detail||e.detail==1){e.preventDefault();var r=t(this);var o=r.find(".tutor_set_withdraw_account_btn");var a=r.serializeObject();o.prop("disabled",true);t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:a,beforeSend:function t(){o.addClass("is-loading")},success:function t(t){if(t.success){tutor_toast(__("Success!","tutor"),t.data.msg,"success")}},complete:function t(){o.removeClass("is-loading");setTimeout(()=>{o.prop("disabled",false)},2e3)}})}});/**
	 * Make Withdraw Form
	 *
	 * @since v.1.2.0
	 */t(document).on("submit","#tutor-earning-withdraw-form",function(e){e.preventDefault();var r=t(this);var o=t("#tutor-earning-withdraw-btn");var a=t(".tutor-withdraw-form-response");var n=r.serializeObject();t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:n,beforeSend:function t(){r.find(".tutor-success-msg").remove();o.attr("disabled","disabled").addClass("is-loading")},success:function e(e){var r;t(".tutor-earning-withdraw-form-wrap").hide();if(e.success){console.log(e.data.available_balance);if(e.data.available_balance!=="undefined"){t(".withdraw-balance-col .available_balance").html(e.data.available_balance)}tutor_toast(__("Request Successful","tutor"),__("Your request has been submitted. Please wait for the administrator's response.","tutor"),"success");setTimeout(function(){location.reload()},500)}else{tutor_toast(__("Error","tutor"),e.data.msg,"error");r='<div class="tutor-error-msg inline-image-text is-inline-block">                            <img src="'+window._tutorobject.tutor_url+'assets/images/icon-cross.svg"/>                             <div>                                <b>Error</b><br/>                                <span>'+e.data.msg+"</span>                            </div>                        </div>";setTimeout(function(){a.html("")},5e3);return false}},complete:function t(){o.removeAttr("disabled").removeClass("is-loading")}})});/**
	 * Delete Course
	 */t(document).on("click",".tutor-dashboard-element-delete-btn",function(e){e.preventDefault();var r=t(this).attr("data-id");t("#tutor-dashboard-delete-element-id").val(r)});t(document).on("submit","#tutor-dashboard-delete-element-form",function(e){e.preventDefault();var r=t("#tutor-dashboard-delete-element-id").val();var o=t(".tutor-modal-element-delete-btn");var a=t(this).serializeObject();t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:a,beforeSend:function t(){o.addClass("is-loading")},success:function e(e){if(e.success){t("#tutor-dashboard-"+e.data.element+"-"+r).remove()}},complete:function t(){o.removeClass("is-loading")}})});/**
	 * Assignment
	 *
	 * @since v.1.3.3
	 */t(document).on("submit","#tutor_assignment_start_form",function(e){e.preventDefault();var r=t(this);var o=r.serializeObject();o.action="tutor_start_assignment";t.ajax({url:_tutorobject.ajaxurl,type:"POST",data:o,beforeSend:function e(){t("#tutor_assignment_start_btn").addClass("is-loading")},success:function t(t){if(t.success){/**
					 * The `true` value will force reload current page
					 * from server instead of browser cache.
					 */location.reload(true)}},error:function t(t,e,r){console.log("assignment start error: "+r)},complete:function e(){t("#tutor_assignment_start_btn").removeClass("is-loading")}})});/**
	 * Assignment answer validation
	 */t(document).on("submit","#tutor_assignment_submit_form",function(t){var e=tinymce.activeEditor.getContent();if(e.trim().length<1){t.preventDefault();tutor_toast(__("Warning","tutor"),__("Assignment answer is required.","tutor"),"error");setTimeout(()=>{jQuery("button#tutor_assignment_submit_btn").removeClass("is-loading").removeAttr("disabled")},500)}});/**
	 * Single Assignment Upload Button
	 * @since v.1.3.4
	 */t("form").on("change",".tutor-assignment-file-upload",function(){t(this).siblings("label").find("span").html(t(this).val().replace(/.*(\/|\\)/,""))});/**
	 * Open the first lesson if all the lessons are closed
	 */if(t(".tutor-accordion-item-header.is-active").length===0){t(".tutor-accordion-item-header").first().trigger("click")}/**
	 *
	 * @type {jQuery}
	 *
	 * Course builder section toggle
	 *
	 * @since v.1.3.5
	 */t(".tutor-course-builder-section-title").on("click",function(){if(t(this).find("i").hasClass("tutor-icon-angle-up")){t(this).find("i").removeClass("tutor-icon-angle-up").addClass("tutor-icon-angle-down")}else{t(this).find("i").removeClass("tutor-icon-angle-down").addClass("tutor-icon-angle-up")}t(this).next("div").slideToggle()});/**
	 * Profile photo upload
	 * @since v.1.4.5
	 */t(document).on("click","#tutor_profile_photo_button",function(e){e.preventDefault();t("#tutor_profile_photo_file").trigger("click")});t(document).on("change","#tutor_profile_photo_file",function(e){e.preventDefault();var r=this;if(r.files&&r.files[0]){var o=new FileReader;o.onload=function(e){t(".tutor-profile-photo-upload-wrap").find("img").attr("src",e.target.result)};o.readAsDataURL(r.files[0])}});/**
	 * Addon, Tutor BuddyPress
	 * Retrieve MetaInformation on BuddyPress message system
	 * @for TutorLMS Pro
	 * @since v.1.4.8
	 */t(document).on("click",".thread-content .subject",function(e){var r=t(this);var o=parseInt(r.closest(".thread-content").attr("data-thread-id"));var a=_tutorobject.nonce_key;var n={thread_id:o,action:"tutor_bp_retrieve_user_records_for_thread"};n[a]=_tutorobject[a];t.ajax({type:"POST",url:window._tutorobject.ajaxurl,data:n,beforeSend:function e(){t("#tutor-bp-thread-wrap").html("")},success:function e(e){if(e.success){t("#tutor-bp-thread-wrap").html(e.data.thread_head_html);l()}}})});function l(){t("ul.tutor-bp-enrolled-course-list").each(function(){var e=t(this);var r=e.find(" > li");var o=3;if(r.length>o){var a=r.length-o;r.each(function(e,r){var a=t(this);if(e>=o){a.hide()}});var n='<a href="javascript:;" class="tutor_bp_plus_courses"><strong>+'+a+" More </strong></a> Courses";e.closest(".tutor-bp-enrolled-courses-wrap").find(".thread-participant-enrolled-info").html(n)}e.show()})}l();t(document).on("click","a.tutor_bp_plus_courses",function(e){e.preventDefault();var r=t(this);r.closest(".tutor-bp-enrolled-courses-wrap").find(".tutor-bp-enrolled-course-list li").show();r.closest(".thread-participant-enrolled-info").html("")});/**
	 * Addon, Tutor Certificate
	 * Certificate dropdown content and copy link
	 * @for TutorLMS Pro
	 * @since v.1.5.1
	 *///$(document).on('click', '.tutor-dropbtn', function (e) {
t(".tutor-dropbtn").click(function(){var e=t(this).parent().find(".tutor-dropdown-content");e.slideToggle(100)});t(document).on("click",function(e){var r=t(".tutor-dropdown");var o=r.find(".tutor-dropdown-content");// if the target of the click isn't the container nor a descendant of the container
if(!r.is(e.target)&&r.has(e.target).length===0){o.slideUp(100)}});/**
	 * Show hide is course public checkbox (frontend dashboard editor)
	 *
	 * @since  v.1.7.2
	 */var d=t('.tutor-frontend-builder-course-price [name="tutor_course_price_type"]');if(d.length==0){t("#_tutor_is_course_public_meta_checkbox").show()}else{d.change(function(){if(t(this).prop("checked")){var e=t(this).val()=="paid"?"hide":"show";t("#_tutor_is_course_public_meta_checkbox")[e]()}}).trigger("change")}/**
	 * Withdrawal page tooltip
	 *
	 * @since  v.1.7.4
	 */// Fully accessible tooltip jQuery plugin with delegation.
// Ideal for view containers that may re-render content.
(function(t){t.fn.tutor_tooltip=function(){this// Delegate to tooltip, Hide if tooltip receives mouse or is clicked (tooltip may stick if parent has focus)
.on("mouseenter click",".tooltip",function(e){e.stopPropagation();t(this).removeClass("isVisible")})// Delegate to parent of tooltip, Show tooltip if parent receives mouse or focus
.on("mouseenter focus",":has(>.tooltip)",function(e){if(!t(this).prop("disabled")){// IE 8 fix to prevent tooltip on `disabled` elements
t(this).find(".tooltip").addClass("isVisible")}})// Delegate to parent of tooltip, Hide tooltip if parent loses mouse or focus
.on("mouseleave blur keydown",":has(>.tooltip)",function(e){if(e.type==="keydown"){if(e.which===27){t(this).find(".tooltip").removeClass("isVisible")}}else{t(this).find(".tooltip").removeClass("isVisible")}});return this}})(jQuery);// Bind event listener to container element
jQuery(".tutor-tooltip-inside").tutor_tooltip();jQuery(".tutor-static-loader").click(function(){setTimeout(()=>{jQuery(this).addClass("is-loading").attr("disabled","disabled")},100)});// Show the snackbar
var v=document.getElementById("tutor-reuseable-snackbar");if(v){// Apply the animation class after a short delay
setTimeout(function(){v.classList.add("tutor-snackbar-show")},1e3);// Adjust the delay (in milliseconds) as needed
}jQuery('#tutor-registration-form [name="password_confirmation"]').on("input",function(){var t=jQuery('[name="password"]');var e=(t.val()||"").trim();var r=e&&jQuery(this).val()===e;jQuery(this).parent().find(".tutor-validation-icon")[r?"show":"hide"]()})})})()})();