<?php
/**
 * Schedule courses
 *
 * @package Tutor\Templates
 * @subpackage Dashboard\My_Courses
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 3.3.1
 */

$active_tab = 'my-courses/schedule-courses';
require dirname( __DIR__ ) . DIRECTORY_SEPARATOR . 'my-courses.php';