<?php
/**
 * Content bank root template.
 *
 * @package TutorPro\Addons
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @since 3.7.0
 */

?>

<div class="tutor-admin-wrap">
	<div id="tutor-content-bank-root"></div>
</div>
